import 'dart:async';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../models/models.dart';
import '../services/mock_data.dart';

class RecordScreen extends StatefulWidget {
  final SceneModel? scene;
  const RecordScreen({super.key, this.scene});
  @override
  State<RecordScreen> createState() => _RecordScreenState();
}

class _RecordScreenState extends State<RecordScreen>
    with SingleTickerProviderStateMixin {
  static const int _max = 30;
  bool _recording = false;
  int _elapsed = 0;
  Timer? _timer;
  SceneModel? _scene;
  late AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _scene = widget.scene ?? MockData.scenes.first;
    _pulse = AnimationController(vsync: this, duration: const Duration(milliseconds: 900));
  }

  @override
  void dispose() { _timer?.cancel(); _pulse.dispose(); super.dispose(); }

  void _start() {
    setState(() { _recording = true; _elapsed = 0; });
    _pulse.repeat(reverse: true);
    _timer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _elapsed++);
      if (_elapsed >= _max) _stop();
    });
  }

  void _stop() {
    _timer?.cancel();
    _pulse.stop();
    setState(() => _recording = false);
    context.go('/preview', extra: {'videoPath': 'mock_path', 'scene': _scene});
  }

  String get _timeDisplay {
    final r = _max - _elapsed;
    final m = r ~/ 60;
    final s = r % 60;
    return '${m.toString().padLeft(2,'0')}:${s.toString().padLeft(2,'0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // ── Camera preview area: dark bg with subtle actor image
          Positioned.fill(
            child: _recording
              ? Image.network(_scene?.thumbnailUrl ?? '', fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(color: const Color(0xFF0A0A0A)))
              : Container(color: const Color(0xFF0A0A0A)),
          ),

          // ── Top bar: X left, photo icon right
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  // X close button
                  GestureDetector(
                    onTap: () => context.go('/home'),
                    child: Container(
                      width: 36, height: 36,
                      decoration: BoxDecoration(
                        color: Colors.black38,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.close, color: Colors.white, size: 20),
                    ),
                  ),
                  // Photo/gallery icon (top right of mockup)
                  Container(
                    width: 36, height: 36,
                    decoration: BoxDecoration(
                      color: Colors.black38,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.photo_library_outlined, color: Colors.white, size: 20),
                  ),
                ],
              ),
            ),
          ),

          // ── Scene title overlay (center top area)
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: Padding(
                padding: const EdgeInsets.only(top: 64),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (_scene != null)
                      Container(
                        margin: const EdgeInsets.symmetric(horizontal: 48),
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          _scene!.title,
                          style: GoogleFonts.dmSans(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600),
                          textAlign: TextAlign.center,
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),

          // ── Countdown timer — large bold (mockup shows "00:28" very large)
          Center(
            child: AnimatedOpacity(
              opacity: _recording ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 200),
              child: Text(
                _timeDisplay,
                style: GoogleFonts.dmSans(
                  fontSize: 72,
                  fontWeight: FontWeight.w800,
                  color: _elapsed >= 25 ? AppColors.red : Colors.white,
                  letterSpacing: -2,
                ),
              ),
            ),
          ),

          // ── Bottom controls
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(32, 20, 32, 48),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black.withOpacity(0.85), Colors.transparent],
                ),
              ),
              child: Column(
                children: [
                  // Progress bar (visible during recording)
                  if (_recording || _elapsed > 0) ...[
                    ClipRRect(
                      borderRadius: BorderRadius.circular(3),
                      child: LinearProgressIndicator(
                        value: _elapsed / _max,
                        backgroundColor: Colors.white24,
                        valueColor: AlwaysStoppedAnimation(
                          _elapsed >= 25 ? AppColors.red : AppColors.yellow,
                        ),
                        minHeight: 3,
                      ),
                    ),
                    const SizedBox(height: 20),
                  ],

                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Scene selector button
                      _CtrlBtn(
                        child: const Icon(Icons.movie_outlined, color: Colors.white, size: 22),
                        label: 'Scènes',
                        onTap: _showScenePicker,
                      ),

                      // ── Main record button (large circle — exactly as mockup)
                      GestureDetector(
                        onTap: _recording ? _stop : _start,
                        child: AnimatedBuilder(
                          animation: _pulse,
                          builder: (_, __) => Container(
                            width: 76, height: 76,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white, width: 3.5),
                              boxShadow: _recording ? [
                                BoxShadow(color: AppColors.red.withOpacity(0.5 + _pulse.value * 0.3),
                                  blurRadius: 20 + _pulse.value * 10, spreadRadius: 3),
                              ] : [],
                            ),
                            child: Center(
                              child: AnimatedContainer(
                                duration: const Duration(milliseconds: 200),
                                width: _recording ? 30 : 62,
                                height: _recording ? 30 : 62,
                                decoration: BoxDecoration(
                                  // Red square when recording, white circle when idle
                                  color: _recording ? AppColors.red : Colors.white,
                                  borderRadius: BorderRadius.circular(_recording ? 7 : 100),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),

                      // Flip camera
                      _CtrlBtn(
                        child: const Icon(Icons.flip_camera_android, color: Colors.white, size: 22),
                        label: 'Retourner',
                        onTap: () {},
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showScenePicker() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.dark,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Column(
        children: [
          const SizedBox(height: 12),
          Container(width: 40, height: 4, decoration: BoxDecoration(color: AppColors.grey, borderRadius: BorderRadius.circular(2))),
          const SizedBox(height: 14),
          Text('Choisir une scène', style: GoogleFonts.dmSans(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.white)),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: MockData.scenes.length,
              itemBuilder: (_, i) {
                final sc = MockData.scenes[i];
                final sel = _scene?.id == sc.id;
                return GestureDetector(
                  onTap: () { setState(() => _scene = sc); Navigator.pop(context); },
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: sel ? AppColors.yellow.withOpacity(0.1) : AppColors.surfaceLight,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: sel ? AppColors.yellow : AppColors.border),
                    ),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: SizedBox(width: 58, height: 44,
                            child: Image.network(sc.thumbnailUrl, fit: BoxFit.cover,
                              errorBuilder: (_, __, ___) => Container(color: AppColors.surface))),
                        ),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(sc.title, style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.white)),
                          Text(sc.category, style: GoogleFonts.dmSans(fontSize: 12, color: AppColors.grey)),
                        ])),
                        if (sel) const Icon(Icons.check_circle, color: AppColors.yellow, size: 18),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _CtrlBtn extends StatelessWidget {
  final Widget child;
  final String label;
  final VoidCallback onTap;
  const _CtrlBtn({required this.child, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Column(
      children: [
        Container(width: 46, height: 46,
          decoration: BoxDecoration(color: Colors.white12, shape: BoxShape.circle),
          child: Center(child: child)),
        const SizedBox(height: 5),
        Text(label, style: GoogleFonts.dmSans(fontSize: 10, color: Colors.white70)),
      ],
    ),
  );
}
