import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';

class LeaderboardScreen extends ConsumerWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(leaderboardProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
          onPressed: () => context.go('/home'),
        ),
        title: Text('Classement',
          style: GoogleFonts.dmSans(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.white)),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // ── Tabs: Jour Semaine Mois Global — exactly as mockup
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 0),
            child: Row(
              children: [
                _Tab('Jour', state.period == 'day', () => ref.read(leaderboardProvider.notifier).load('day')),
                const SizedBox(width: 8),
                _Tab('Semaine', state.period == 'week', () => ref.read(leaderboardProvider.notifier).load('week')),
                const SizedBox(width: 8),
                _Tab('Mois', state.period == 'month', () => ref.read(leaderboardProvider.notifier).load('month')),
                const SizedBox(width: 8),
                _Tab('Global', state.period == 'global', () => ref.read(leaderboardProvider.notifier).load('global')),
              ],
            ),
          ),
          const SizedBox(height: 4),

          // ── Leaderboard list (numbered rows as in mockup)
          Expanded(
            child: state.isLoading
              ? const Center(child: CircularProgressIndicator(color: AppColors.yellow))
              : ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
                  itemCount: state.entries.length,
                  itemBuilder: (ctx, i) {
                    final e = state.entries[i];
                    return GestureDetector(
                      onTap: () => context.go('/profile/${e.user.id}'),
                      child: Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                        decoration: BoxDecoration(
                          // Rank 1 gets slight yellow tint
                          color: e.rank == 1
                            ? AppColors.yellow.withOpacity(0.08)
                            : AppColors.cardDark,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(
                            color: e.rank == 1 ? AppColors.yellow.withOpacity(0.25) : AppColors.border,
                          ),
                        ),
                        child: Row(
                          children: [
                            // ── Rank number (left)
                            SizedBox(
                              width: 24,
                              child: Text(
                                '${e.rank}',
                                style: GoogleFonts.dmSans(
                                  fontSize: 15, fontWeight: FontWeight.w700,
                                  color: e.rank <= 3 ? AppColors.yellow : AppColors.grey,
                                ),
                              ),
                            ),
                            const SizedBox(width: 10),

                            // ── Avatar
                            UserAvatar(url: e.user.avatarUrl, size: 40),
                            const SizedBox(width: 12),

                            // ── Name + badges (star icons)
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text(e.user.username,
                                        style: GoogleFonts.dmSans(
                                          fontSize: 14, fontWeight: FontWeight.w700,
                                          color: AppColors.white,
                                        )),
                                      if (e.user.isVerified) ...[
                                        const SizedBox(width: 4),
                                        const Icon(Icons.verified_rounded, size: 13, color: AppColors.cyan),
                                      ],
                                    ],
                                  ),
                                  // Badge icons (⭐ or 🔥 dots)
                                  Row(
                                    children: [
                                      // Follower count
                                      Text(
                                        MockData.formatCount(e.user.followersCount),
                                        style: GoogleFonts.dmSans(fontSize: 12, color: AppColors.grey),
                                      ),
                                      // Mini badge emojis
                                      if (e.rank <= 3) ...[
                                        const SizedBox(width: 4),
                                        const Text('🔥', style: TextStyle(fontSize: 12)),
                                      ],
                                    ],
                                  ),
                                ],
                              ),
                            ),

                            // ── Score with heart icon
                            Row(
                              children: [
                                Text(
                                  e.scoreLabel.replaceAll(' ❤️', ''),
                                  style: GoogleFonts.dmSans(
                                    fontSize: 14, fontWeight: FontWeight.w700,
                                    color: AppColors.white,
                                  ),
                                ),
                                const SizedBox(width: 4),
                                const Icon(Icons.favorite, size: 14, color: AppColors.red),
                              ],
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                ),
          ),
        ],
      ),
    );
  }
}

Widget _Tab(String label, bool sel, VoidCallback onTap) {
  return GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: sel ? AppColors.yellow : Colors.transparent,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: sel ? AppColors.yellow : Colors.transparent),
      ),
      child: Text(label,
        style: GoogleFonts.dmSans(
          fontSize: 13, fontWeight: FontWeight.w600,
          color: sel ? AppColors.navy : AppColors.grey,
        )),
    ),
  );
}
