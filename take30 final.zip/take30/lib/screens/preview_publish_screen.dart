import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../models/models.dart';
import '../services/mock_data.dart';

class PreviewPublishScreen extends StatefulWidget {
  final String? videoPath;
  final SceneModel? scene;
  const PreviewPublishScreen({super.key, this.videoPath, this.scene});
  @override
  State<PreviewPublishScreen> createState() => _PreviewPublishScreenState();
}

class _PreviewPublishScreenState extends State<PreviewPublishScreen> {
  final _titleCtrl = TextEditingController();
  String _selectedCategory = 'Drame';
  bool _publishing = false;

  @override
  void initState() {
    super.initState();
    _titleCtrl.text = widget.scene?.title ?? 'Annonce d\'une mauvaise nouvelle';
    _selectedCategory = widget.scene?.category ?? 'Drame';
  }

  @override
  void dispose() { _titleCtrl.dispose(); super.dispose(); }

  Future<void> _publish() async {
    setState(() => _publishing = true);
    await Future.delayed(const Duration(seconds: 2));
    if (!mounted) return;
    setState(() => _publishing = false);
    _showSuccess();
  }

  void _showSuccess() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: AppColors.cardDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('🎉', style: TextStyle(fontSize: 48)),
              const SizedBox(height: 14),
              Text('Publié avec succès !',
                style: GoogleFonts.dmSans(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.white)),
              const SizedBox(height: 8),
              Text('Ta scène est maintenant visible. Bonne chance !',
                style: GoogleFonts.dmSans(fontSize: 13, color: AppColors.grey),
                textAlign: TextAlign.center),
              const SizedBox(height: 24),
              SizedBox(width: double.infinity, height: 48,
                child: ElevatedButton(
                  onPressed: () { Navigator.pop(context); context.go('/profile/u1'); },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.yellow,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                  child: Text('Voir mon profil', style: GoogleFonts.dmSans(fontWeight: FontWeight.w700, color: AppColors.navy)),
                )),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () { Navigator.pop(context); context.go('/home'); },
                child: Text('Retour à l\'accueil', style: GoogleFonts.dmSans(color: AppColors.grey))),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final scene = widget.scene ?? MockData.scenes[3];

    return Scaffold(
      backgroundColor: AppColors.navy,
      // ── App bar: X left, "Modifier" text right — exactly as mockup
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.close, color: AppColors.white, size: 22),
          onPressed: () => context.go('/record'),
        ),
        actions: [
          TextButton(
            onPressed: () {},
            child: Text('Modifier',
              style: GoogleFonts.dmSans(color: AppColors.white, fontSize: 14, fontWeight: FontWeight.w600)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Full-width preview with play button overlay
            Stack(
              children: [
                SizedBox(
                  width: double.infinity,
                  height: 260,
                  child: Image.network(
                    scene.thumbnailUrl,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(color: AppColors.cardDark),
                  ),
                ),
                // Gradient overlay
                Positioned.fill(
                  child: Container(
                    decoration: const BoxDecoration(
                      gradient: LinearGradient(
                        colors: [Colors.transparent, Color(0x88000000)],
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                      ),
                    ),
                  ),
                ),
                // ── Play button (white circle — matches mockup)
                const Positioned.fill(
                  child: Center(
                    child: DecoratedBox(
                      decoration: BoxDecoration(
                        color: Colors.transparent,
                        shape: BoxShape.circle,
                      ),
                      child: Icon(Icons.play_circle_fill, color: Colors.white, size: 64),
                    ),
                  ),
                ),
                // ── Category chips (Drame, Annonce, Solo) — bottom left
                Positioned(
                  bottom: 12, left: 12,
                  child: Row(
                    children: [
                      _TagChip('Drame', AppColors.purple),
                      const SizedBox(width: 6),
                      _TagChip('Annonce', AppColors.purple),
                      const SizedBox(width: 6),
                      _TagChip('Solo', AppColors.purple),
                    ],
                  ),
                ),
              ],
            ),

            // ── Form area
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 20, 16, 0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Titre field
                  Text('Titre',
                    style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.greyLight)),
                  const SizedBox(height: 8),
                  Container(
                    decoration: BoxDecoration(
                      color: AppColors.surfaceLight,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: TextField(
                      controller: _titleCtrl,
                      style: GoogleFonts.dmSans(color: AppColors.white, fontSize: 14),
                      decoration: const InputDecoration(
                        border: InputBorder.none,
                        contentPadding: EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Category chips
                  Text('Catégorie',
                    style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.greyLight)),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8, runSpacing: 8,
                    children: MockData.categories.map((cat) {
                      final sel = _selectedCategory == cat.name;
                      return GestureDetector(
                        onTap: () => setState(() => _selectedCategory = cat.name),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 150),
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                          decoration: BoxDecoration(
                            color: sel ? AppColors.yellow.withOpacity(0.15) : AppColors.surfaceLight,
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(color: sel ? AppColors.yellow : AppColors.border),
                          ),
                          child: Text('${cat.emoji} ${cat.name}',
                            style: GoogleFonts.dmSans(
                              fontSize: 13, fontWeight: FontWeight.w600,
                              color: sel ? AppColors.yellow : AppColors.white)),
                        ),
                      );
                    }).toList(),
                  ),

                  const SizedBox(height: 32),

                  // ── Publier button — full yellow (matches mockup)
                  SizedBox(
                    width: double.infinity, height: 52,
                    child: ElevatedButton(
                      onPressed: _publishing ? null : _publish,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.yellow,
                        foregroundColor: AppColors.navy,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: _publishing
                        ? const SizedBox(width: 20, height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.navy))
                        : Text('Publier',
                            style: GoogleFonts.dmSans(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.navy)),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Recommencer outline button
                  SizedBox(
                    width: double.infinity, height: 52,
                    child: OutlinedButton(
                      onPressed: () => context.go('/record'),
                      style: OutlinedButton.styleFrom(
                        side: const BorderSide(color: AppColors.border),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      ),
                      child: Text('Recommencer',
                        style: GoogleFonts.dmSans(fontSize: 15, fontWeight: FontWeight.w600, color: AppColors.white)),
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

Widget _TagChip(String label, Color color) {
  return Container(
    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
    decoration: BoxDecoration(
      color: color.withOpacity(0.75),
      borderRadius: BorderRadius.circular(6),
    ),
    child: Text(label,
      style: GoogleFonts.dmSans(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.white)),
  );
}
