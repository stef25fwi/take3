import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../services/mock_data.dart';
import '../models/models.dart';

class BadgesStatsScreen extends ConsumerWidget {
  const BadgesStatsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = MockData.users[0];

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy, elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
          onPressed: () => context.go('/profile/u1'),
        ),
        title: Text('Badges & Stats',
          style: GoogleFonts.dmSans(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.white)),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── "Tes badges" + "Voir tout" header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Tes badges',
                  style: GoogleFonts.dmSans(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.white)),
                GestureDetector(
                  onTap: () {},
                  child: Text('Voir tout',
                    style: GoogleFonts.dmSans(fontSize: 14, color: AppColors.cyan, fontWeight: FontWeight.w600)),
                ),
              ],
            ),
            const SizedBox(height: 14),

            // ── 4 badge icons in a row (matches mockup: ⭐🏆🎭🔥)
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: MockData.badges.map((b) {
                final Color c = b.type == BadgeType.gold ? AppColors.yellow
                  : b.type == BadgeType.silver ? AppColors.greyLight
                  : b.type == BadgeType.bronze ? const Color(0xFFCD7F32)
                  : AppColors.purple;
                return Expanded(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4),
                    padding: const EdgeInsets.symmetric(vertical: 14),
                    decoration: BoxDecoration(
                      color: AppColors.cardDark,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: c.withOpacity(0.35)),
                    ),
                    child: Column(
                      children: [
                        // Badge circle
                        Container(
                          width: 48, height: 48,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: c.withOpacity(0.15),
                            border: Border.all(color: c.withOpacity(0.5), width: 2),
                          ),
                          child: Center(child: Text(b.emoji, style: const TextStyle(fontSize: 24))),
                        ),
                        const SizedBox(height: 8),
                        Text(b.name,
                          style: GoogleFonts.dmSans(fontSize: 10, fontWeight: FontWeight.w600, color: AppColors.white),
                          textAlign: TextAlign.center, maxLines: 2,
                          overflow: TextOverflow.ellipsis),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),

            const SizedBox(height: 28),

            // ── "Stats" header
            Text('Stats',
              style: GoogleFonts.dmSans(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.white)),
            const SizedBox(height: 14),

            // ── Stat rows — exactly as mockup
            _StatRow(
              icon: Icons.play_circle_outline_rounded,
              iconColor: AppColors.cyan,
              label: 'Vues totales',
              value: MockData.formatCount(user.totalViews),
            ),
            _StatRow(
              icon: Icons.thumb_up_alt_outlined,
              iconColor: AppColors.green,
              label: 'Taux d\'approbation',
              value: '${user.approvalRate.toInt()}%',
              valueColor: AppColors.green,
              showProgress: true,
              progress: user.approvalRate / 100,
              progressColor: AppColors.green,
            ),
            _StatRow(
              icon: Icons.share_outlined,
              iconColor: AppColors.yellow,
              label: 'Partages',
              value: MockData.formatCount(user.sharesCount),
            ),
            _StatRow(
              icon: Icons.movie_filter_outlined,
              iconColor: AppColors.purple,
              label: 'Scènes jouées',
              value: '${user.scenesCount}',
            ),

            const SizedBox(height: 28),

            // ── Chart section
            Text('Évolution des vues',
              style: GoogleFonts.dmSans(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.white)),
            const SizedBox(height: 12),
            Container(
              height: 140,
              decoration: BoxDecoration(
                color: AppColors.cardDark,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              padding: const EdgeInsets.all(14),
              child: _MiniChart(),
            ),
          ],
        ),
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label, value;
  final Color? valueColor;
  final bool showProgress;
  final double progress;
  final Color? progressColor;

  const _StatRow({
    required this.icon, required this.iconColor,
    required this.label, required this.value,
    this.valueColor, this.showProgress = false,
    this.progress = 0, this.progressColor,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        children: [
          Row(
            children: [
              // Icon container
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: iconColor, size: 19),
              ),
              const SizedBox(width: 14),
              // Label
              Expanded(
                child: Text(label,
                  style: GoogleFonts.dmSans(fontSize: 15, color: AppColors.greyLight, fontWeight: FontWeight.w500)),
              ),
              // Value + arrow
              Text(value,
                style: GoogleFonts.dmSans(
                  fontSize: 18, fontWeight: FontWeight.w800,
                  color: valueColor ?? AppColors.white,
                )),
              const SizedBox(width: 6),
              const Icon(Icons.arrow_forward_ios, size: 13, color: AppColors.grey),
            ],
          ),
          if (showProgress) ...[
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: progress,
                backgroundColor: AppColors.surfaceLight,
                valueColor: AlwaysStoppedAnimation(progressColor ?? AppColors.cyan),
                minHeight: 6,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _MiniChart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final bars = [0.3, 0.5, 0.4, 0.7, 0.6, 0.8, 0.65, 0.9, 0.75, 0.85, 0.7, 1.0];
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: bars.map((v) => Expanded(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 2),
          child: Container(
            height: v * 90,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [AppColors.cyan.withOpacity(0.4), AppColors.cyan],
                begin: Alignment.bottomCenter, end: Alignment.topCenter,
              ),
              borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
            ),
          ),
        ),
      )).toList(),
    );
  }
}
