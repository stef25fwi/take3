import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../services/mock_data.dart';
import '../models/models.dart';
import '../widgets/shared_widgets.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final feedState = ref.watch(feedProvider);
    final scenes = feedState.scenes.isEmpty ? MockData.scenes : feedState.scenes;

    return Scaffold(
      backgroundColor: AppColors.navy,
      body: CustomScrollView(
        slivers: [
          // ── Top bar (matches mockup: filter icon left, avatar icon right)
          SliverAppBar(
            backgroundColor: AppColors.navy,
            elevation: 0,
            floating: true,
            pinned: false,
            toolbarHeight: 56,
            title: Row(
              children: [
                // Filter/sort icon (left side of mockup)
                Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    color: AppColors.surfaceLight,
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: const Icon(Icons.tune_rounded, color: AppColors.white, size: 18),
                ),
              ],
            ),
            actions: [
              // Avatar top right (matches mockup)
              GestureDetector(
                onTap: () => context.go('/profile/u1'),
                child: Container(
                  margin: const EdgeInsets.only(right: 16),
                  child: const UserAvatar(
                    url: 'https://i.pravatar.cc/150?img=47',
                    size: 34,
                    showBorder: true,
                  ),
                ),
              ),
            ],
          ),

          // ── Feed — TikTok-style vertical scroll
          if (feedState.isLoading)
            const SliverFillRemaining(
              child: Center(child: CircularProgressIndicator(color: AppColors.yellow)),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (ctx, i) => _FeedItem(
                  scene: scenes[i % scenes.length],
                  onLike: () => ref.read(feedProvider.notifier).toggleLike(scenes[i % scenes.length].id),
                  onProfile: () => context.go('/profile/${scenes[i % scenes.length].author.id}'),
                  onScene: () => context.go('/scene/${scenes[i % scenes.length].id}'),
                ),
                childCount: scenes.length,
              ),
            ),

          const SliverToBoxAdapter(child: SizedBox(height: 20)),
        ],
      ),
    );
  }
}

/// ── Feed item: matches mockup screen 3 exactly
/// Portrait-style photo/video, right-side actions (like, comment, share),
/// bottom: user avatar + name, title, category tag
class _FeedItem extends StatefulWidget {
  final SceneModel scene;
  final VoidCallback onLike, onProfile, onScene;
  const _FeedItem({required this.scene, required this.onLike, required this.onProfile, required this.onScene});

  @override
  State<_FeedItem> createState() => _FeedItemState();
}

class _FeedItemState extends State<_FeedItem> {
  bool _liked = false;

  @override
  Widget build(BuildContext context) {
    final s = widget.scene;

    return GestureDetector(
      onDoubleTap: () => setState(() => _liked = !_liked),
      onTap: widget.onScene,
      child: Container(
        // Each card: full width with 16px margin, rounded corners, fixed height
        margin: const EdgeInsets.fromLTRB(16, 0, 16, 16),
        height: 420,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          color: AppColors.cardDark,
        ),
        clipBehavior: Clip.hardEdge,
        child: Stack(
          children: [
            // ── Background image (portrait crop)
            Positioned.fill(
              child: Image.network(
                s.thumbnailUrl,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: AppColors.cardDark),
              ),
            ),

            // ── Gradient overlay bottom
            Positioned.fill(
              child: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [
                      Colors.transparent,
                      Colors.transparent,
                      Color(0xAA000000),
                      Color(0xEE000000),
                    ],
                    stops: [0.0, 0.45, 0.72, 1.0],
                  ),
                ),
              ),
            ),

            // ── Right side: action buttons (like / comment / share)
            // Positioned on right edge, vertically centered-bottom
            Positioned(
              right: 12,
              bottom: 90,
              child: Column(
                children: [
                  // Like
                  _SideAction(
                    icon: _liked ? Icons.favorite : Icons.favorite_border_rounded,
                    color: _liked ? AppColors.red : Colors.white,
                    count: MockData.formatCount(s.likesCount + (_liked ? 1 : 0)),
                    onTap: () { setState(() => _liked = !_liked); widget.onLike(); },
                  ),
                  const SizedBox(height: 18),
                  // Comment
                  _SideAction(
                    icon: Icons.chat_bubble_outline_rounded,
                    color: Colors.white,
                    count: MockData.formatCount(s.commentsCount),
                    onTap: () {},
                  ),
                  const SizedBox(height: 18),
                  // Share
                  _SideAction(
                    icon: Icons.reply_rounded, // mirror for share
                    color: Colors.white,
                    count: 'Share',
                    onTap: () {},
                    flip: true,
                  ),
                ],
              ),
            ),

            // ── Bottom info: user + title
            Positioned(
              bottom: 16, left: 14, right: 72,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Author row
                  GestureDetector(
                    onTap: widget.onProfile,
                    child: Row(
                      children: [
                        UserAvatar(url: s.author.avatarUrl, size: 30),
                        const SizedBox(width: 8),
                        Text(
                          s.author.username,
                          style: GoogleFonts.dmSans(
                            fontSize: 14, fontWeight: FontWeight.w700,
                            color: Colors.white,
                          ),
                        ),
                        if (s.author.isVerified) ...[
                          const SizedBox(width: 4),
                          const Icon(Icons.verified_rounded, size: 13, color: AppColors.cyan),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(height: 6),
                  // Scene title + category
                  Text(
                    '${s.title} (${s.category})',
                    style: GoogleFonts.dmSans(
                      fontSize: 13, fontWeight: FontWeight.w500,
                      color: Colors.white,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),

            // ── Stats bar at very bottom (total likes + comments inline)
            Positioned(
              bottom: -2, left: 0, right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                child: Row(
                  children: [
                    const Icon(Icons.favorite, size: 13, color: Colors.white70),
                    const SizedBox(width: 4),
                    Text(MockData.formatCount(s.likesCount),
                      style: GoogleFonts.dmSans(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w600)),
                    const SizedBox(width: 12),
                    const Icon(Icons.chat_bubble_outline, size: 13, color: Colors.white70),
                    const SizedBox(width: 4),
                    Text(MockData.formatCount(s.commentsCount),
                      style: GoogleFonts.dmSans(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _SideAction extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String count;
  final VoidCallback onTap;
  final bool flip;

  const _SideAction({
    required this.icon, required this.color,
    required this.count, required this.onTap,
    this.flip = false,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Transform(
            alignment: Alignment.center,
            transform: flip ? (Matrix4.identity()..scale(-1.0, 1.0)) : Matrix4.identity(),
            child: Icon(icon, size: 28, color: color),
          ),
          const SizedBox(height: 3),
          Text(count, style: GoogleFonts.dmSans(fontSize: 11, color: Colors.white, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
