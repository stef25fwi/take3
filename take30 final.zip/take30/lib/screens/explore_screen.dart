import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';
import '../models/models.dart';

class ExploreScreen extends ConsumerStatefulWidget {
  const ExploreScreen({super.key});
  @override
  ConsumerState<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends ConsumerState<ExploreScreen> {
  final _searchCtrl = TextEditingController();
  String? _selectedCatId;

  @override
  void dispose() { _searchCtrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(exploreProvider);
    final cats = state.categories.isEmpty ? MockData.categories : state.categories;
    final scenes = state.scenes.isEmpty ? MockData.scenes : state.scenes;

    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // ── Search bar row (matches mockup: text field + emoji button right)
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: Container(
                        height: 44,
                        decoration: BoxDecoration(
                          color: AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: TextField(
                          controller: _searchCtrl,
                          style: GoogleFonts.dmSans(color: AppColors.white, fontSize: 14),
                          decoration: InputDecoration(
                            hintText: 'Rechercher une scène...',
                            hintStyle: GoogleFonts.dmSans(color: AppColors.grey, fontSize: 14),
                            prefixIcon: const Icon(Icons.search, color: AppColors.grey, size: 19),
                            border: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            contentPadding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    // Emoji/filter icon button
                    Container(
                      width: 44, height: 44,
                      decoration: BoxDecoration(
                        color: AppColors.surfaceLight,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: const Center(child: Text('😊', style: TextStyle(fontSize: 20))),
                    ),
                  ],
                ),
              ),
            ),

            // ── "Catégories" header + chips row
            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 18, 16, 10),
                    child: Text('Catégories',
                      style: GoogleFonts.dmSans(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.white)),
                  ),
                  // Horizontal chips row — Drame, Comédie, Action, Romance, Thriller
                  SizedBox(
                    height: 46,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: cats.length,
                      itemBuilder: (_, i) {
                        final c = cats[i];
                        final sel = _selectedCatId == c.id;
                        return GestureDetector(
                          onTap: () {
                            setState(() => _selectedCatId = sel ? null : c.id);
                            ref.read(exploreProvider.notifier).selectCategory(sel ? '' : c.id);
                          },
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 180),
                            margin: const EdgeInsets.only(right: 8),
                            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 0),
                            decoration: BoxDecoration(
                              color: sel ? AppColors.yellow : AppColors.surfaceLight,
                              borderRadius: BorderRadius.circular(22),
                              border: Border.all(color: sel ? AppColors.yellow : AppColors.border),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                // Category emoji icon block (matches mockup rounded square icon)
                                Container(
                                  width: 26, height: 26,
                                  decoration: BoxDecoration(
                                    color: sel ? AppColors.navy.withOpacity(0.2) : AppColors.border,
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: Center(child: Text(c.emoji, style: const TextStyle(fontSize: 14))),
                                ),
                                const SizedBox(width: 7),
                                Text(c.name,
                                  style: GoogleFonts.dmSans(
                                    fontSize: 13, fontWeight: FontWeight.w600,
                                    color: sel ? AppColors.navy : AppColors.white,
                                  )),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),

            // ── "Scènes populaires" header
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
                child: Text('Scènes populaires',
                  style: GoogleFonts.dmSans(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.white)),
              ),
            ),

            // ── Popular grid (3 columns with duration badge — matches mockup)
            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) {
                    if (state.isLoading) {
                      return const ShimmerBox(width: double.infinity, height: 90);
                    }
                    final sc = scenes[i % scenes.length];
                    return _SceneThumbnail(scene: sc, onTap: () => context.go('/scene/${sc.id}'));
                  },
                  childCount: state.isLoading ? 6 : (scenes.length < 3 ? scenes.length : 3),
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: 0.72,
                ),
              ),
            ),

            // ── "Nouvelles scènes" header
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 22, 16, 10),
                child: Text('Nouvelles scènes',
                  style: GoogleFonts.dmSans(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.white)),
              ),
            ),

            // ── New scenes grid
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (ctx, i) {
                    final sc = MockData.scenes[i % MockData.scenes.length];
                    return _SceneThumbnail(scene: sc, onTap: () => context.go('/scene/${sc.id}'));
                  },
                  childCount: 6,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                  childAspectRatio: 0.72,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Thumbnail card with duration badge — matches explore mockup
class _SceneThumbnail extends StatelessWidget {
  final SceneModel scene;
  final VoidCallback onTap;
  const _SceneThumbnail({required this.scene, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.network(scene.thumbnailUrl, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(color: AppColors.cardDark)),
            // Gradient bottom
            const Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, Color(0xCC000000)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: [0.5, 1.0],
                  ),
                ),
              ),
            ),
            // Duration badge bottom-left
            Positioned(
              bottom: 5, left: 5,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                decoration: BoxDecoration(
                  color: Colors.black54,
                  borderRadius: BorderRadius.circular(4),
                ),
                child: Text(scene.durationFormatted,
                  style: GoogleFonts.dmSans(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
