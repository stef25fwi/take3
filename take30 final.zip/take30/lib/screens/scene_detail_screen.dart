import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';
import '../models/models.dart';

class SceneDetailScreen extends StatefulWidget {
  final String sceneId;
  const SceneDetailScreen({super.key, required this.sceneId});
  @override
  State<SceneDetailScreen> createState() => _SceneDetailScreenState();
}

class _SceneDetailScreenState extends State<SceneDetailScreen> {
  bool _liked = false;
  late SceneModel _scene;

  @override
  void initState() {
    super.initState();
    _scene = MockData.scenes.firstWhere(
      (s) => s.id == widget.sceneId, orElse: () => MockData.scenes.first);
    _liked = _scene.isLiked;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Full screen thumbnail
          Positioned.fill(
            child: GestureDetector(
              onTap: () {},
              child: Image.network(_scene.thumbnailUrl, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: Colors.black)),
            ),
          ),
          // Gradient overlay
          const Positioned.fill(child: DecoratedBox(decoration: BoxDecoration(gradient: AppColors.darkOverlay))),

          // Top bar
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.of(context).pop(),
                    child: Container(
                      width: 36, height: 36,
                      decoration: const BoxDecoration(color: Colors.black38, shape: BoxShape.circle),
                      child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
                    ),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: AppColors.purple.withOpacity(0.8),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Text(_scene.category,
                      style: GoogleFonts.dmSans(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
          ),

          // Play button center
          Center(
            child: Container(
              width: 68, height: 68,
              decoration: BoxDecoration(color: Colors.black38, shape: BoxShape.circle,
                border: Border.all(color: Colors.white38, width: 2)),
              child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 40),
            ),
          ),

          // Bottom info
          Positioned(
            bottom: 0, left: 0, right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(18, 20, 18, 36),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter, end: Alignment.topCenter,
                  colors: [Colors.black.withOpacity(0.9), Colors.transparent],
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => context.go('/profile/${_scene.author.id}'),
                        child: Row(
                          children: [
                            UserAvatar(url: _scene.author.avatarUrl, size: 38, showBorder: true),
                            const SizedBox(width: 10),
                            Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                Text(_scene.author.username,
                                  style: GoogleFonts.dmSans(fontSize: 15, fontWeight: FontWeight.w700, color: Colors.white)),
                                if (_scene.author.isVerified) ...[
                                  const SizedBox(width: 4),
                                  const Icon(Icons.verified, size: 13, color: AppColors.cyan),
                                ],
                              ]),
                              Text(_scene.durationFormatted,
                                style: GoogleFonts.dmSans(fontSize: 11, color: Colors.white60)),
                            ]),
                          ],
                        ),
                      ),
                      const Spacer(),
                      GestureDetector(
                        onTap: () => context.go('/record', extra: _scene),
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
                          decoration: BoxDecoration(
                            gradient: AppColors.primaryGradient,
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Text('Jouer',
                            style: GoogleFonts.dmSans(fontSize: 13, fontWeight: FontWeight.w700, color: AppColors.navy)),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  Text(_scene.title,
                    style: GoogleFonts.dmSans(fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _Act(
                        icon: _liked ? Icons.favorite : Icons.favorite_border,
                        color: _liked ? AppColors.red : Colors.white,
                        label: MockData.formatCount(_scene.likesCount),
                        onTap: () => setState(() => _liked = !_liked),
                      ),
                      const SizedBox(width: 18),
                      _Act(icon: Icons.comment_outlined, color: Colors.white,
                        label: MockData.formatCount(_scene.commentsCount), onTap: () {}),
                      const SizedBox(width: 18),
                      _Act(icon: Icons.share_outlined, color: Colors.white,
                        label: MockData.formatCount(_scene.sharesCount), onTap: () {}),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _Act extends StatelessWidget {
  final IconData icon; final Color color; final String label; final VoidCallback onTap;
  const _Act({required this.icon, required this.color, required this.label, required this.onTap});
  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Row(children: [
      Icon(icon, color: color, size: 22),
      const SizedBox(width: 5),
      Text(label, style: GoogleFonts.dmSans(fontSize: 13, color: color, fontWeight: FontWeight.w600)),
    ]),
  );
}
