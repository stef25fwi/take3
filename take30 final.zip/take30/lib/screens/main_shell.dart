import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';

class MainShell extends StatelessWidget {
  final Widget child;
  const MainShell({super.key, required this.child});

  int _idx(BuildContext ctx) {
    final loc = GoRouterState.of(ctx).uri.path;
    if (loc.startsWith('/home')) return 0;
    if (loc.startsWith('/explore')) return 1;
    if (loc.startsWith('/record')) return 2;
    if (loc.startsWith('/notifications')) return 3;
    if (loc.startsWith('/profile')) return 4;
    return 0;
  }

  void _go(BuildContext ctx, int i) {
    switch (i) {
      case 0: ctx.go('/home'); break;
      case 1: ctx.go('/explore'); break;
      case 2: ctx.go('/record'); break;
      case 3: ctx.go('/notifications'); break;
      case 4: ctx.go('/profile/u1'); break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final idx = _idx(context);
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: child,
      bottomNavigationBar: Container(
        decoration: const BoxDecoration(
          color: AppColors.dark,
          border: Border(top: BorderSide(color: AppColors.border, width: 0.5)),
        ),
        child: SafeArea(
          top: false,
          child: SizedBox(
            height: 58,
            child: Row(
              children: [
                _Tab(icon: Icons.home_rounded, label: 'Accueil', sel: idx == 0, onTap: () => _go(context, 0)),
                _Tab(icon: Icons.explore_rounded, label: 'Explorer', sel: idx == 1, onTap: () => _go(context, 1)),
                // Center + button — yellow filled circle
                Expanded(
                  child: GestureDetector(
                    onTap: () => _go(context, 2),
                    child: Center(
                      child: Container(
                        width: 46, height: 46,
                        decoration: BoxDecoration(
                          color: AppColors.yellow,
                          shape: BoxShape.circle,
                          boxShadow: [BoxShadow(color: AppColors.yellow.withOpacity(0.35), blurRadius: 12, spreadRadius: 1)],
                        ),
                        child: const Icon(Icons.add, color: AppColors.navy, size: 26),
                      ),
                    ),
                  ),
                ),
                _Tab(icon: Icons.notifications_outlined, label: 'Notifs', sel: idx == 3, onTap: () => _go(context, 3)),
                _Tab(icon: Icons.person_outline_rounded, label: 'Profil', sel: idx == 4, onTap: () => _go(context, 4)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _Tab extends StatelessWidget {
  final IconData icon;
  final String label;
  final bool sel;
  final VoidCallback onTap;
  const _Tab({required this.icon, required this.label, required this.sel, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = sel ? AppColors.yellow : AppColors.grey;
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 22, color: color),
            const SizedBox(height: 3),
            Text(label, style: GoogleFonts.dmSans(fontSize: 10, color: color,
              fontWeight: sel ? FontWeight.w600 : FontWeight.w400)),
          ],
        ),
      ),
    );
  }
}
