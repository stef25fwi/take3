import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../services/mock_data.dart';
import '../widgets/shared_widgets.dart';

class BattleScreen extends ConsumerWidget {
  const BattleScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(duelProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
          onPressed: () => context.go('/home'),
        ),
        title: Text('Battle / Duel',
          style: GoogleFonts.dmSans(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.white)),
        centerTitle: true,
      ),
      body: state.isLoading
        ? const Center(child: CircularProgressIndicator(color: AppColors.yellow))
        : state.duel == null
          ? const Center(child: Text('Aucun duel disponible'))
          : _BattleBody(
              duel: state.duel!,
              onVote: (c) => ref.read(duelProvider.notifier).vote(c),
            ),
    );
  }
}

class _BattleBody extends StatelessWidget {
  final dynamic duel;
  final Function(int) onVote;
  const _BattleBody({required this.duel, required this.onVote});

  @override
  Widget build(BuildContext context) {
    final voted = duel.userVote != null;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 14),
      child: Column(
        children: [
          // ── "Qui a le mieux joué?" — bold center title
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 14),
            child: Text(
              'Qui a le mieux joué ?',
              style: GoogleFonts.dmSans(
                fontSize: 20, fontWeight: FontWeight.w700,
                color: AppColors.white,
              ),
              textAlign: TextAlign.center,
            ),
          ),

          // ── Two videos side by side with VS in middle
          Expanded(
            child: Row(
              children: [
                // Video A
                Expanded(
                  child: _VideoPanel(
                    scene: duel.sceneA,
                    label: 'A',
                    votes: duel.votesA,
                    pct: duel.percentA,
                    voted: voted,
                    winner: voted && duel.votesA >= duel.votesB,
                    onTap: voted ? null : () => onVote(0),
                    color: AppColors.yellow,
                  ),
                ),

                // VS badge in center
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 6),
                  child: Container(
                    width: 34, height: 34,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.surfaceLight,
                      border: Border.all(color: AppColors.border),
                    ),
                    child: Center(
                      child: Text('VS',
                        style: GoogleFonts.dmSans(
                          fontSize: 11, fontWeight: FontWeight.w900,
                          color: AppColors.yellow,
                        )),
                    ),
                  ),
                ),

                // Video B
                Expanded(
                  child: _VideoPanel(
                    scene: duel.sceneB,
                    label: 'B',
                    votes: duel.votesB,
                    pct: duel.percentB,
                    voted: voted,
                    winner: voted && duel.votesB > duel.votesA,
                    onTap: voted ? null : () => onVote(1),
                    color: AppColors.cyan,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── Vote buttons (matches mockup: yellow A, blue B)
          if (!voted)
            Row(
              children: [
                Expanded(
                  child: GestureDetector(
                    onTap: () => onVote(0),
                    child: Container(
                      height: 52,
                      decoration: BoxDecoration(
                        color: AppColors.yellow,
                        borderRadius: BorderRadius.circular(14),
                      ),
                      child: Center(
                        child: Text('🅰 Voter A',
                          style: GoogleFonts.dmSans(
                            fontSize: 16, fontWeight: FontWeight.w700,
                            color: AppColors.navy,
                          )),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: GestureDetector(
                    onTap: () => onVote(1),
                    child: Container(
                      height: 52,
                      decoration: BoxDecoration(
                        color: const Color(0xFF1E3A8A), // blue matching mockup
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(color: AppColors.cyan.withOpacity(0.5)),
                      ),
                      child: Center(
                        child: Text('🅱 Voter B',
                          style: GoogleFonts.dmSans(
                            fontSize: 16, fontWeight: FontWeight.w700,
                            color: AppColors.white,
                          )),
                      ),
                    ),
                  ),
                ),
              ],
            )
          else
            Column(
              children: [
                Text(
                  'Tu as voté pour ${duel.userVote == 0 ? duel.sceneA.author.username : duel.sceneB.author.username} 🎉',
                  style: GoogleFonts.dmSans(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.yellow),
                ),
                const SizedBox(height: 10),
                _ResultBar(label: duel.sceneA.author.username, pct: duel.percentA, color: AppColors.yellow),
                const SizedBox(height: 6),
                _ResultBar(label: duel.sceneB.author.username, pct: duel.percentB, color: AppColors.cyan),
              ],
            ),

          const SizedBox(height: 20),
        ],
      ),
    );
  }
}

class _VideoPanel extends StatelessWidget {
  final dynamic scene;
  final String label;
  final int votes;
  final double pct;
  final bool voted, winner;
  final VoidCallback? onTap;
  final Color color;

  const _VideoPanel({
    required this.scene, required this.label, required this.votes,
    required this.pct, required this.voted, required this.winner,
    required this.onTap, required this.color,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(14),
        child: Stack(
          children: [
            // Video thumbnail
            Positioned.fill(
              child: Image.network(scene.thumbnailUrl, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: AppColors.cardDark)),
            ),
            // Gradient
            const Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Colors.transparent, Color(0xDD000000)],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    stops: [0.45, 1.0],
                  ),
                ),
              ),
            ),
            // A/B label top-left
            Positioned(
              top: 10, left: 10,
              child: Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                  color: color,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(label,
                    style: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w900,
                      color: AppColors.navy)),
                ),
              ),
            ),
            // Winner trophy
            if (winner)
              Positioned(top: 10, right: 10,
                child: const Text('🏆', style: TextStyle(fontSize: 22))),
            // User info bottom
            Positioned(
              bottom: 10, left: 8, right: 8,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    UserAvatar(url: scene.author.avatarUrl, size: 24),
                    const SizedBox(width: 5),
                    Expanded(child: Text(scene.author.username,
                      style: GoogleFonts.dmSans(fontSize: 12, fontWeight: FontWeight.w700, color: Colors.white),
                      overflow: TextOverflow.ellipsis)),
                  ]),
                  if (voted) ...[
                    const SizedBox(height: 4),
                    Text(MockData.formatCount(votes),
                      style: GoogleFonts.dmSans(fontSize: 11, color: color, fontWeight: FontWeight.w700)),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ResultBar extends StatelessWidget {
  final String label;
  final double pct;
  final Color color;
  const _ResultBar({required this.label, required this.pct, required this.color});

  @override
  Widget build(BuildContext context) => Row(
    children: [
      SizedBox(width: 70,
        child: Text(label, style: GoogleFonts.dmSans(fontSize: 12, color: AppColors.greyLight),
          overflow: TextOverflow.ellipsis)),
      const SizedBox(width: 8),
      Expanded(
        child: ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(value: pct, backgroundColor: AppColors.surfaceLight,
            valueColor: AlwaysStoppedAnimation(color), minHeight: 8),
        ),
      ),
      const SizedBox(width: 8),
      Text('${(pct*100).toInt()}%',
        style: GoogleFonts.dmSans(fontSize: 12, color: color, fontWeight: FontWeight.w700)),
    ],
  );
}
