import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';

class DailyChallengeScreen extends ConsumerWidget {
  const DailyChallengeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(dailyChallengeProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy, elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
          onPressed: () => context.go('/home'),
        ),
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text('🔥', style: TextStyle(fontSize: 18)),
            const SizedBox(width: 6),
            Text('Défi du Jour',
              style: GoogleFonts.dmSans(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.white)),
          ],
        ),
        centerTitle: true,
        actions: [
          // Notification bell active (matches mockup yellow bell)
          Stack(
            children: [
              IconButton(
                icon: const Icon(Icons.notifications, color: AppColors.yellow, size: 24),
                onPressed: () => context.go('/notifications'),
              ),
              Positioned(
                top: 8, right: 8,
                child: Container(
                  width: 8, height: 8,
                  decoration: const BoxDecoration(color: AppColors.red, shape: BoxShape.circle),
                ),
              ),
            ],
          ),
        ],
      ),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.yellow)),
        error: (_, __) => const Center(child: Text('Erreur', style: TextStyle(color: AppColors.grey))),
        data: (challenge) => SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ── Main card: layout matches mockup
              // Left: title + quote + rules | Right: scene photo
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
                child: Container(
                  decoration: BoxDecoration(
                    color: AppColors.cardDark,
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.border),
                  ),
                  clipBehavior: Clip.hardEdge,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // ── Left content
                      Expanded(
                        flex: 3,
                        child: Padding(
                          padding: const EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              // "🔥 Défi du Jour" badge
                              Container(
                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                decoration: BoxDecoration(
                                  color: AppColors.red.withOpacity(0.15),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Row(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    const Text('🔥', style: TextStyle(fontSize: 13)),
                                    const SizedBox(width: 5),
                                    Text('Défi du Jour',
                                      style: GoogleFonts.dmSans(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.red)),
                                  ],
                                ),
                              ),
                              const SizedBox(height: 12),

                              // Scene title
                              Text(challenge.sceneTitle,
                                style: GoogleFonts.dmSans(fontSize: 16, fontWeight: FontWeight.w800, color: AppColors.white)),
                              const SizedBox(height: 6),

                              // Quote in italic (matches mockup exactly)
                              Text(
                                '"Tu m\'as trahi."',
                                style: GoogleFonts.dmSans(
                                  fontSize: 15, fontWeight: FontWeight.w600,
                                  color: AppColors.greyLight,
                                  fontStyle: FontStyle.italic,
                                ),
                              ),
                              const SizedBox(height: 14),

                              // ── Bullet rules list (matches mockup: ★ 30 secondes max, ★ Joue avec émotion, ★ Partage pour gagner)
                              ...challenge.rules.map((r) => Padding(
                                padding: const EdgeInsets.only(bottom: 7),
                                child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const Text('★  ', style: TextStyle(color: AppColors.yellow, fontSize: 11)),
                                    Expanded(
                                      child: Text(r,
                                        style: GoogleFonts.dmSans(fontSize: 13, color: AppColors.greyLight)),
                                    ),
                                  ],
                                ),
                              )),
                            ],
                          ),
                        ),
                      ),

                      // ── Right: scene photo
                      Expanded(
                        flex: 2,
                        child: SizedBox(
                          height: 200,
                          child: Image.network(
                            challenge.thumbnailUrl,
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(color: AppColors.surface),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 20),

              // ── Timer countdown
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: _CountdownRow(expiresAt: challenge.expiresAt),
              ),

              const SizedBox(height: 20),

              // ── Participants count
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Row(
                  children: [
                    // Stacked avatars
                    SizedBox(
                      width: 70, height: 28,
                      child: Stack(
                        children: List.generate(3, (i) => Positioned(
                          left: i * 18.0,
                          child: UserAvatar(url: 'https://i.pravatar.cc/150?img=${25 + i}', size: 28, showBorder: true),
                        )),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Text(
                      '+${MockData.formatCount(challenge.participantsCount)} participants',
                      style: GoogleFonts.dmSans(fontSize: 13, color: AppColors.greyLight, fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // ── "Relever le défi" yellow button (full width, matches mockup)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: SizedBox(
                  width: double.infinity, height: 52,
                  child: ElevatedButton(
                    onPressed: () => context.go('/record'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.yellow,
                      foregroundColor: AppColors.navy,
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text('Relever le défi',
                      style: GoogleFonts.dmSans(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.navy)),
                  ),
                ),
              ),

              const SizedBox(height: 12),

              // ── See participations outline
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: SizedBox(
                  width: double.infinity, height: 48,
                  child: OutlinedButton(
                    onPressed: () => context.go('/explore'),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.border),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                    ),
                    child: Text('Voir les participations',
                      style: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.white)),
                  ),
                ),
              ),

              const SizedBox(height: 28),

              // ── Past challenges thumbnails
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                child: Text('Défis précédents',
                  style: GoogleFonts.dmSans(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.white)),
              ),
              SizedBox(
                height: 120,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: 4,
                  itemBuilder: (_, i) {
                    final sc = MockData.scenes[i % MockData.scenes.length];
                    return Container(
                      width: 105, margin: const EdgeInsets.only(right: 10),
                      decoration: BoxDecoration(borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.border)),
                      clipBehavior: Clip.hardEdge,
                      child: Stack(fit: StackFit.expand, children: [
                        Image.network(sc.thumbnailUrl, fit: BoxFit.cover, errorBuilder: (_, __, ___) => Container(color: AppColors.cardDark)),
                        const DecoratedBox(decoration: BoxDecoration(gradient: AppColors.darkOverlay)),
                        Positioned(top: 6, left: 6,
                          child: Container(
                            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
                            decoration: BoxDecoration(color: Colors.black45, borderRadius: BorderRadius.circular(4)),
                            child: Text('J-${i+1}', style: GoogleFonts.dmSans(fontSize: 10, color: AppColors.greyLight, fontWeight: FontWeight.w600)),
                          )),
                      ]),
                    );
                  },
                ),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }
}

class _CountdownRow extends StatefulWidget {
  final DateTime expiresAt;
  const _CountdownRow({required this.expiresAt});
  @override
  State<_CountdownRow> createState() => _CountdownRowState();
}

class _CountdownRowState extends State<_CountdownRow> {
  late Duration _remaining;
  @override
  void initState() {
    super.initState();
    _remaining = widget.expiresAt.difference(DateTime.now());
    _tick();
  }
  void _tick() {
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) { setState(() => _remaining = widget.expiresAt.difference(DateTime.now())); _tick(); }
    });
  }
  String get _fmt {
    if (_remaining.isNegative) return 'Expiré';
    final h = _remaining.inHours;
    final m = _remaining.inMinutes.remainder(60).toString().padLeft(2,'0');
    final s = _remaining.inSeconds.remainder(60).toString().padLeft(2,'0');
    return '${h}h ${m}m ${s}s';
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
      decoration: BoxDecoration(
        color: AppColors.cardDark,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.yellow.withOpacity(0.2)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          const Icon(Icons.timer_outlined, color: AppColors.yellow, size: 18),
          const SizedBox(width: 8),
          Text('Se termine dans $_fmt',
            style: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.white)),
        ],
      ),
    );
  }
}
