import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';
import '../models/models.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  final String userId;
  const ProfileScreen({super.key, required this.userId});
  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final profileState = ref.watch(profileProvider(widget.userId));
    final user = profileState.user ?? MockData.users[0];
    final isOwn = widget.userId == 'u1';

    return Scaffold(
      backgroundColor: AppColors.navy,
      body: NestedScrollView(
        headerSliverBuilder: (ctx, innerBoxScrolled) => [
          SliverAppBar(
            backgroundColor: AppColors.navy,
            elevation: 0,
            pinned: true,
            floating: false,
            expandedHeight: 300,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
              onPressed: () => context.go('/home'),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.search, color: AppColors.white, size: 22),
                onPressed: () {},
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              collapseMode: CollapseMode.pin,
              background: _ProfileHeader(user: user, isOwn: isOwn, onFollow: () {
                ref.read(profileProvider(widget.userId).notifier).toggleFollow();
              }),
            ),
          ),
        ],
        body: Column(
          children: [
            // ── Tabs: Performances | Badges | Favoris
            Container(
              color: AppColors.navy,
              child: TabBar(
                controller: _tabs,
                indicatorColor: AppColors.yellow,
                indicatorWeight: 2,
                labelColor: AppColors.white,
                unselectedLabelColor: AppColors.grey,
                labelStyle: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w600),
                unselectedLabelStyle: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w400),
                tabs: const [
                  Tab(text: 'Performances'),
                  Tab(text: 'Badges'),
                  Tab(text: 'Favoris'),
                ],
              ),
            ),
            Expanded(
              child: TabBarView(
                controller: _tabs,
                children: [
                  _GridTab(scenes: profileState.scenes.isEmpty ? MockData.scenes : profileState.scenes),
                  _BadgesGridTab(),
                  _GridTab(scenes: MockData.scenes.reversed.toList()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// ── Profile header: avatar centered, name+verified, role, stats, action buttons
class _ProfileHeader extends StatelessWidget {
  final UserModel user;
  final bool isOwn;
  final VoidCallback onFollow;
  const _ProfileHeader({required this.user, required this.isOwn, required this.onFollow});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [Color(0xFF0D1626), Color(0xFF111827)],
          begin: Alignment.topCenter, end: Alignment.bottomCenter,
        ),
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 56, 20, 16),
          child: Column(
            children: [
              // ── Avatar (larger, centered like mockup)
              Stack(
                children: [
                  UserAvatar(url: user.avatarUrl, size: 80, showBorder: true),
                  if (user.isVerified)
                    Positioned(
                      bottom: 2, right: 2,
                      child: Container(
                        width: 22, height: 22,
                        decoration: const BoxDecoration(color: AppColors.cyan, shape: BoxShape.circle),
                        child: const Icon(Icons.check, size: 13, color: Colors.white),
                      ),
                    ),
                ],
              ),
              const SizedBox(height: 10),

              // Name + verified icon
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(user.displayName,
                    style: GoogleFonts.dmSans(fontSize: 20, fontWeight: FontWeight.w800, color: AppColors.white)),
                  if (user.isVerified) ...[
                    const SizedBox(width: 5),
                    const Icon(Icons.verified, size: 18, color: AppColors.cyan),
                  ],
                ],
              ),
              const SizedBox(height: 4),
              // Role/bio line (matches mockup: "Actrice / Créatrice")
              Text(user.bio.isEmpty ? 'Actrice / Créatrice' : user.bio,
                style: GoogleFonts.dmSans(fontSize: 13, color: AppColors.grey)),

              const SizedBox(height: 16),

              // ── Stats row: Scènes | Followers | Likes
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  _Stat('${user.scenesCount}', 'Scènes'),
                  _Divider(),
                  _Stat(MockData.formatCount(user.followersCount), 'Followers'),
                  _Divider(),
                  _Stat(MockData.formatCount(user.likesCount), 'Likes'),
                ],
              ),

              const SizedBox(height: 16),

              // ── Action buttons: Suivre (yellow) | Message (outline) | download icon
              Row(
                children: [
                  // Suivre button
                  Expanded(
                    child: GestureDetector(
                      onTap: onFollow,
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 200),
                        height: 40,
                        decoration: BoxDecoration(
                          color: user.isFollowing ? AppColors.surfaceLight : AppColors.yellow,
                          borderRadius: BorderRadius.circular(10),
                          border: user.isFollowing ? Border.all(color: AppColors.border) : null,
                        ),
                        child: Center(
                          child: Text(
                            user.isFollowing ? 'Suivi ✓' : 'Suivre',
                            style: GoogleFonts.dmSans(
                              fontSize: 14, fontWeight: FontWeight.w700,
                              color: user.isFollowing ? AppColors.greyLight : AppColors.navy,
                            )),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  // Message button (outline)
                  Expanded(
                    child: Container(
                      height: 40,
                      decoration: BoxDecoration(
                        color: AppColors.surfaceLight,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: Center(
                        child: Text('Message',
                          style: GoogleFonts.dmSans(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.white)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 10),
                  // Download/share icon button
                  Container(
                    width: 40, height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.surfaceLight,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: AppColors.border),
                    ),
                    child: const Icon(Icons.file_download_outlined, color: AppColors.white, size: 18),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

Widget _Stat(String value, String label) => Padding(
  padding: const EdgeInsets.symmetric(horizontal: 20),
  child: Column(
    children: [
      Text(value, style: GoogleFonts.dmSans(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.white)),
      const SizedBox(height: 2),
      Text(label, style: GoogleFonts.dmSans(fontSize: 12, color: AppColors.grey)),
    ],
  ),
);

Widget _Divider() => Container(width: 1, height: 32, color: AppColors.border);

/// ── Grid of scene thumbnails (Performances tab)
class _GridTab extends StatelessWidget {
  final List<dynamic> scenes;
  const _GridTab({required this.scenes});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(2),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
        childAspectRatio: 0.82,
      ),
      itemCount: scenes.length + 2,
      itemBuilder: (ctx, i) {
        final sc = scenes[i % scenes.length];
        return Stack(
          children: [
            Positioned.fill(
              child: Image.network(sc.thumbnailUrl, fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: AppColors.cardDark)),
            ),
            // Stats row at bottom
            Positioned(
              bottom: 0, left: 0, right: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 5),
                color: Colors.black54,
                child: Row(
                  children: [
                    const Icon(Icons.favorite, size: 11, color: AppColors.red),
                    const SizedBox(width: 3),
                    Text(MockData.formatCount(sc.likesCount),
                      style: GoogleFonts.dmSans(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w600)),
                    const SizedBox(width: 8),
                    const Icon(Icons.remove_red_eye_outlined, size: 11, color: AppColors.cyan),
                    const SizedBox(width: 3),
                    Text(MockData.formatCount(sc.viewsCount),
                      style: GoogleFonts.dmSans(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w600)),
                    const SizedBox(width: 8),
                    const Icon(Icons.share, size: 11, color: AppColors.yellow),
                    const SizedBox(width: 3),
                    Text(MockData.formatCount(sc.sharesCount),
                      style: GoogleFonts.dmSans(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w600)),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

/// ── Badges grid
class _BadgesGridTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12, childAspectRatio: 1.1,
      ),
      itemCount: MockData.badges.length,
      itemBuilder: (_, i) {
        final b = MockData.badges[i];
        final Color c = b.type == BadgeType.gold ? AppColors.yellow
          : b.type == BadgeType.silver ? AppColors.greyLight
          : b.type == BadgeType.bronze ? const Color(0xFFCD7F32)
          : AppColors.purple;
        return Container(
          decoration: BoxDecoration(
            color: AppColors.cardDark,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: c.withOpacity(0.3)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(b.emoji, style: const TextStyle(fontSize: 32)),
              const SizedBox(height: 8),
              Text(b.name, style: GoogleFonts.dmSans(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.white),
                textAlign: TextAlign.center, maxLines: 2),
            ],
          ),
        );
      },
    );
  }
}
