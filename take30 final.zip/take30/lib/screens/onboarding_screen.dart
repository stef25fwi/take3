import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});
  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..forward();
  }

  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  // Mockup feature list items
  static const List<Map<String,String>> _features = [
    {'icon': '🎬', 'label': 'Scènes quotidiennes'},
    {'icon': '⚔️',  'label': 'Défis & Duels'},
    {'icon': '🏆', 'label': 'Classements'},
    {'icon': '🌟', 'label': 'Découverte de talents'},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      body: Stack(
        children: [
          // ── Full-screen cinematic background image
          Positioned.fill(
            child: Image.network(
              'https://images.unsplash.com/photo-1526510747491-58f928ec870f?w=800&q=80',
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [Color(0xFF1A1025), AppColors.navy],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ),
          ),

          // ── Gradient overlay — heavier at bottom
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Colors.black.withOpacity(0.35),
                    Colors.black.withOpacity(0.60),
                    AppColors.navy.withOpacity(0.92),
                    AppColors.navy,
                  ],
                  stops: const [0.0, 0.35, 0.65, 1.0],
                ),
              ),
            ),
          ),

          // ── Content
          SafeArea(
            child: FadeTransition(
              opacity: CurvedAnimation(parent: _ctrl, curve: const Interval(0, 0.8, curve: Curves.easeOut)),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 52),

                    // ── Logo: "Take30" white bold
                    Text(
                      'Take30',
                      style: GoogleFonts.dmSans(
                        fontSize: 44,
                        fontWeight: FontWeight.w800,
                        color: AppColors.white,
                        letterSpacing: -1.5,
                        height: 1,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'Prouve ton talent\nen 30 secondes',
                      style: GoogleFonts.dmSans(
                        fontSize: 17,
                        fontWeight: FontWeight.w400,
                        color: AppColors.greyLight,
                        height: 1.4,
                      ),
                    ),

                    const Spacer(),

                    // ── Headline
                    SlideTransition(
                      position: Tween<Offset>(begin: const Offset(0, 0.4), end: Offset.zero)
                          .animate(CurvedAnimation(parent: _ctrl, curve: const Interval(0.25, 0.9, curve: Curves.easeOut))),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Rejoue des scènes\n& deviens viral',
                            style: GoogleFonts.dmSans(
                              fontSize: 27,
                              fontWeight: FontWeight.w700,
                              color: AppColors.white,
                              height: 1.2,
                            ),
                          ),
                          const SizedBox(height: 24),

                          // ── Feature list — exactly as mockup
                          ..._features.map((f) => Padding(
                            padding: const EdgeInsets.only(bottom: 16),
                            child: Row(
                              children: [
                                // Icon in a subtle container
                                Container(
                                  width: 36, height: 36,
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.08),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Center(child: Text(f['icon']!, style: const TextStyle(fontSize: 17))),
                                ),
                                const SizedBox(width: 14),
                                Text(
                                  f['label']!,
                                  style: GoogleFonts.dmSans(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w500,
                                    color: AppColors.white,
                                  ),
                                ),
                              ],
                            ),
                          )),

                          const SizedBox(height: 28),

                          // ── CTA Buttons (exactly as mockup)
                          // Primary: yellow rounded
                          SizedBox(
                            width: double.infinity, height: 52,
                            child: ElevatedButton(
                              onPressed: () => context.go('/auth?tab=register'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppColors.yellow,
                                foregroundColor: AppColors.navy,
                                elevation: 0,
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              ),
                              child: Text('Commencer',
                                style: GoogleFonts.dmSans(
                                  fontSize: 16, fontWeight: FontWeight.w700,
                                  color: AppColors.navy,
                                )),
                            ),
                          ),
                          const SizedBox(height: 12),

                          // Secondary: outline white
                          SizedBox(
                            width: double.infinity, height: 52,
                            child: OutlinedButton(
                              onPressed: () => context.go('/auth?tab=login'),
                              style: OutlinedButton.styleFrom(
                                foregroundColor: AppColors.white,
                                side: const BorderSide(color: Colors.white30, width: 1.5),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                              ),
                              child: Text('Se connecter',
                                style: GoogleFonts.dmSans(
                                  fontSize: 16, fontWeight: FontWeight.w600,
                                  color: AppColors.white,
                                )),
                            ),
                          ),

                          const SizedBox(height: 12),

                          // ── "Créer un compte" link (mockup shows this as yellow text button)
                          Center(
                            child: TextButton(
                              onPressed: () => context.go('/auth?tab=register'),
                              child: Text(
                                'Créer un compte',
                                style: GoogleFonts.dmSans(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.yellow,
                                  decoration: TextDecoration.underline,
                                  decorationColor: AppColors.yellow,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 8),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
