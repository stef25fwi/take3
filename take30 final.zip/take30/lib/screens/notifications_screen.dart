import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../models/models.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifsAsync = ref.watch(notificationsProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy, elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
          onPressed: () => context.go('/home'),
        ),
        title: Text('Notifications',
          style: GoogleFonts.dmSans(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.white)),
        centerTitle: true,
        actions: [
          IconButton(
            icon: const Icon(Icons.search, color: AppColors.white, size: 22),
            onPressed: () {},
          ),
        ],
      ),
      body: notifsAsync.when(
        loading: () => ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: 5,
          itemBuilder: (_, __) => const Padding(
            padding: EdgeInsets.only(bottom: 10),
            child: ShimmerBox(width: double.infinity, height: 72, borderRadius: 14),
          ),
        ),
        error: (_, __) => const Center(child: Text('Erreur', style: TextStyle(color: AppColors.grey))),
        data: (notifs) => ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
          itemCount: notifs.length,
          itemBuilder: (ctx, i) => _NotifRow(notif: notifs[i], onTap: () {
            switch (notifs[i].type) {
              case NotificationType.duel: context.go('/battle'); break;
              case NotificationType.achievement: context.go('/badges'); break;
              default: context.go('/home'); break;
            }
          }),
        ),
      ),
    );
  }
}

class _NotifRow extends StatelessWidget {
  final NotificationModel notif;
  final VoidCallback onTap;
  const _NotifRow({required this.notif, required this.onTap});

  @override
  Widget build(BuildContext context) {
    // Icon color & icon by type
    IconData iconData;
    Color iconColor;
    switch (notif.type) {
      case NotificationType.like:
        iconData = Icons.favorite; iconColor = AppColors.red; break;
      case NotificationType.comment:
        iconData = Icons.chat_bubble; iconColor = AppColors.cyan; break;
      case NotificationType.duel:
        iconData = Icons.sports_mma; iconColor = AppColors.purple; break;
      case NotificationType.achievement:
        iconData = Icons.emoji_events; iconColor = AppColors.yellow; break;
      case NotificationType.system:
        iconData = Icons.info; iconColor = AppColors.grey; break;
    }

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
        decoration: BoxDecoration(
          color: notif.isRead ? AppColors.cardDark : AppColors.surfaceLight,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: notif.isRead ? AppColors.border : AppColors.purple.withOpacity(0.25),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            // ── Left: avatar with icon badge, OR just icon circle
            if (notif.avatarUrl != null)
              Stack(
                children: [
                  UserAvatar(url: notif.avatarUrl, size: 44),
                  // Small icon badge bottom-right
                  Positioned(
                    bottom: 0, right: 0,
                    child: Container(
                      width: 17, height: 17,
                      decoration: BoxDecoration(
                        color: iconColor, shape: BoxShape.circle,
                        border: Border.all(color: AppColors.dark, width: 1.5),
                      ),
                      child: Icon(iconData, size: 9, color: Colors.white),
                    ),
                  ),
                ],
              )
            else
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                  color: iconColor.withOpacity(0.15),
                  shape: BoxShape.circle,
                ),
                child: Icon(iconData, color: iconColor, size: 22),
              ),

            const SizedBox(width: 12),

            // ── Message + time
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(notif.message,
                    style: GoogleFonts.dmSans(
                      fontSize: 14, fontWeight: FontWeight.w600,
                      color: AppColors.white,
                    )),
                  const SizedBox(height: 3),
                  Text(notif.subMessage,
                    style: GoogleFonts.dmSans(fontSize: 12, color: AppColors.grey)),
                ],
              ),
            ),

            const SizedBox(width: 8),

            // ── Right: unread dot + optional action button
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (!notif.isRead)
                  Container(
                    width: 8, height: 8,
                    decoration: const BoxDecoration(color: AppColors.cyan, shape: BoxShape.circle),
                  ),
                if (notif.type == NotificationType.duel || notif.type == NotificationType.achievement) ...[
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.yellow.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.yellow.withOpacity(0.3)),
                    ),
                    child: Text(
                      notif.type == NotificationType.duel ? 'Voter →' : 'Voir →',
                      style: GoogleFonts.dmSans(fontSize: 11, color: AppColors.yellow, fontWeight: FontWeight.w700),
                    ),
                  ),
                ],
              ],
            ),
          ],
        ),
      ),
    );
  }
}
