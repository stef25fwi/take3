package com.take30.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
