# Take30 — Flutter MVP

> **Prouve ton talent en 30 secondes**  
> App de performance d'acting viral — 12 écrans complets, navigation, state management, API mock.

---

## 🚀 Installation rapide

### Prérequis
- Flutter SDK >= 3.0.0
- Dart >= 3.0.0
- iOS 14+ ou Android 6+

### Setup

```bash
# 1. Cloner / copier le projet
cd take30

# 2. Installer les dépendances
flutter pub get

# 3. Lancer l'app
flutter run
```

---

## 📱 Écrans & Navigation

| # | Écran | Route | Description |
|---|-------|-------|-------------|
| 1 | **Splash** | `/splash` | Animation logo + redirect auto |
| 2 | **Onboarding** | `/onboarding` | Présentation features, hero image |
| — | **Auth** | `/auth?tab=login` | Login + Register avec tabs |
| 3 | **Accueil / Feed** | `/home` | Feed vertical avec cards scènes |
| 4 | **Explorer** | `/explore` | Grid scènes, filtres catégories, search |
| 5 | **Enregistrement** | `/record` | Caméra + countdown 30s + sélection scène |
| 6 | **Aperçu / Publier** | `/preview` | Preview vidéo, titre, catégorie, publish |
| 7 | **Battle / Duel** | `/battle` | Vote A vs B avec résultats animés |
| 8 | **Classement** | `/leaderboard` | Podium Top 3 + liste avec tabs Jour/Semaine/Mois |
| 9 | **Profil Talent** | `/profile/:userId` | Stats, scènes, badges, follow |
| 10 | **Badges & Stats** | `/badges` | Badges, graphique vues, top performances |
| 11 | **Notifications** | `/notifications` | Feed notifs avec types (like, duel, badge…) |
| 12 | **Défi du Jour** | `/challenge` | Challenge avec countdown live + règles |
| — | **Scène Detail** | `/scene/:id` | Vue full-screen + commentaires bottom sheet |

---

## 🏗️ Architecture

```
lib/
├── main.dart                   # Entry point, ProviderScope
├── theme/
│   └── app_theme.dart          # Couleurs, typographie, composants
├── models/
│   └── models.dart             # UserModel, SceneModel, DuelModel…
├── services/
│   ├── api_service.dart        # Couche API (mock → remplaçable REST)
│   └── mock_data.dart          # Données réalistes
├── providers/
│   └── providers.dart          # Riverpod StateNotifiers par feature
├── router/
│   └── router.dart             # GoRouter, ShellRoute bottom nav
├── widgets/
│   └── shared_widgets.dart     # PrimaryButton, UserAvatar, SceneCard…
└── screens/
    ├── splash_screen.dart
    ├── onboarding_screen.dart
    ├── auth_screen.dart
    ├── main_shell.dart          # Bottom nav shell
    ├── home_screen.dart
    ├── explore_screen.dart
    ├── record_screen.dart
    ├── preview_publish_screen.dart
    ├── battle_screen.dart
    ├── leaderboard_screen.dart
    ├── profile_screen.dart
    ├── badges_stats_screen.dart
    ├── notifications_screen.dart
    ├── daily_challenge_screen.dart
    └── scene_detail_screen.dart
```

---

## 🎨 Charte visuelle

| Token | Valeur | Usage |
|-------|--------|-------|
| `navy` | `#081020` | Background principal |
| `dark` | `#111827` | Bottom nav, cards |
| `yellow` | `#FFB800` | CTA primaire, accents |
| `cyan` | `#00D4FF` | Secondaire, verified |
| `purple` | `#6C5CE7` | Categories, badges |
| `red` | `#FF4757` | Likes, urgence |

**Typographie** : DM Sans (Google Fonts)

---

## 🔌 Remplacer l'API Mock

Toute la logique API est dans `lib/services/api_service.dart`.  
Pour brancher une vraie API REST :

```dart
// Remplacer les délais mock par de vrais appels Dio :
Future<List<SceneModel>> getFeed({int page = 0}) async {
  final response = await _dio.get('/feed?page=$page');
  return (response.data as List).map((j) => SceneModel.fromJson(j)).toList();
}
```

---

## 📦 Dépendances clés

| Package | Usage |
|---------|-------|
| `flutter_riverpod` | State management |
| `go_router` | Navigation déclarative |
| `google_fonts` | DM Sans typography |
| `cached_network_image` | Images réseau optimisées |
| `camera` | Enregistrement vidéo |
| `video_player` | Lecture vidéo |

---

## 📋 Roadmap MVP → Production

- [ ] Intégrer `camera` plugin pour vrai enregistrement
- [ ] Intégrer `video_player` pour lecture dans le feed  
- [ ] Connecter API REST (Node.js / Supabase recommandé)
- [ ] Push notifications (Firebase FCM)
- [ ] Auth sociale (Google, Apple)
- [ ] Storage vidéo (Firebase Storage / AWS S3)
- [ ] Modération contenu (filtres IA)
