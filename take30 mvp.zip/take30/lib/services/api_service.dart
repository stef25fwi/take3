import 'dart:async';
import '../models/models.dart';
import 'mock_data.dart';

/// Simulates API calls with realistic delays
class ApiService {
  static final ApiService _instance = ApiService._internal();
  factory ApiService() => _instance;
  ApiService._internal();

  // Auth state
  bool _isAuthenticated = false;
  UserModel? _currentUser;

  bool get isAuthenticated => _isAuthenticated;
  UserModel? get currentUser => _currentUser;

  // ─── Auth ─────────────────────────────────────────────────────────────────

  Future<UserModel> login(String email, String password) async {
    await Future.delayed(const Duration(milliseconds: 800));
    _isAuthenticated = true;
    _currentUser = MockData.users[0];
    return _currentUser!;
  }

  Future<UserModel> register(String username, String email, String password) async {
    await Future.delayed(const Duration(seconds: 1));
    _isAuthenticated = true;
    _currentUser = MockData.users[0].copyWith();
    return _currentUser!;
  }

  Future<void> logout() async {
    await Future.delayed(const Duration(milliseconds: 300));
    _isAuthenticated = false;
    _currentUser = null;
  }

  // ─── Feed ─────────────────────────────────────────────────────────────────

  Future<List<SceneModel>> getFeed({int page = 0}) async {
    await Future.delayed(const Duration(milliseconds: 600));
    return MockData.scenes;
  }

  Future<List<SceneModel>> getPopularScenes(String category) async {
    await Future.delayed(const Duration(milliseconds: 500));
    if (category == 'all') return MockData.scenes;
    return MockData.scenes.where((s) => s.category.toLowerCase() == category.toLowerCase()).toList();
  }

  Future<List<CategoryModel>> getCategories() async {
    await Future.delayed(const Duration(milliseconds: 300));
    return MockData.categories;
  }

  // ─── Interactions ─────────────────────────────────────────────────────────

  Future<bool> likeScene(String sceneId) async {
    await Future.delayed(const Duration(milliseconds: 200));
    return true;
  }

  Future<bool> followUser(String userId) async {
    await Future.delayed(const Duration(milliseconds: 300));
    return true;
  }

  // ─── Leaderboard ──────────────────────────────────────────────────────────

  Future<List<LeaderboardEntry>> getLeaderboard(String period) async {
    await Future.delayed(const Duration(milliseconds: 500));
    return MockData.leaderboard;
  }

  // ─── Profile ──────────────────────────────────────────────────────────────

  Future<UserModel> getProfile(String userId) async {
    await Future.delayed(const Duration(milliseconds: 400));
    return MockData.users.firstWhere(
      (u) => u.id == userId,
      orElse: () => MockData.users[0],
    );
  }

  Future<List<SceneModel>> getUserScenes(String userId) async {
    await Future.delayed(const Duration(milliseconds: 400));
    return MockData.scenes.where((s) => s.author.id == userId).toList();
  }

  // ─── Duel ─────────────────────────────────────────────────────────────────

  Future<DuelModel> getCurrentDuel() async {
    await Future.delayed(const Duration(milliseconds: 400));
    return MockData.currentDuel;
  }

  Future<DuelModel> vote(String duelId, int choice) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final duel = MockData.currentDuel;
    return duel.copyWith(
      userVote: choice,
      votesA: choice == 0 ? duel.votesA + 1 : duel.votesA,
      votesB: choice == 1 ? duel.votesB + 1 : duel.votesB,
    );
  }

  // ─── Notifications ────────────────────────────────────────────────────────

  Future<List<NotificationModel>> getNotifications() async {
    await Future.delayed(const Duration(milliseconds: 400));
    return MockData.notifications;
  }

  // ─── Daily Challenge ─────────────────────────────────────────────────────

  Future<DailyChallengeModel> getDailyChallenge() async {
    await Future.delayed(const Duration(milliseconds: 400));
    return MockData.dailyChallenge;
  }

  // ─── Upload ───────────────────────────────────────────────────────────────

  Future<SceneModel> uploadScene({
    required String videoPath,
    required String title,
    required String category,
    required List<String> tags,
  }) async {
    await Future.delayed(const Duration(seconds: 2));
    return SceneModel(
      id: 'new_${DateTime.now().millisecondsSinceEpoch}',
      title: title,
      category: category,
      thumbnailUrl: 'https://images.unsplash.com/photo-1542513217-0b0eeea7f7bc?w=400',
      durationSeconds: 28,
      author: _currentUser ?? MockData.users[0],
      createdAt: DateTime.now(),
      tags: tags,
    );
  }
}
