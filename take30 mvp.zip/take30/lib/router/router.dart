import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../screens/splash_screen.dart';
import '../screens/onboarding_screen.dart';
import '../screens/auth_screen.dart';
import '../screens/main_shell.dart';
import '../screens/home_screen.dart';
import '../screens/explore_screen.dart';
import '../screens/record_screen.dart';
import '../screens/preview_publish_screen.dart';
import '../screens/notifications_screen.dart';
import '../screens/profile_screen.dart';
import '../screens/leaderboard_screen.dart';
import '../screens/battle_screen.dart';
import '../screens/badges_stats_screen.dart';
import '../screens/daily_challenge_screen.dart';
import '../screens/scene_detail_screen.dart';
import '../providers/providers.dart';
import '../models/models.dart';

final routerProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: '/splash',
    routes: [
      GoRoute(
        path: '/splash',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/onboarding',
        builder: (context, state) => const OnboardingScreen(),
      ),
      GoRoute(
        path: '/auth',
        builder: (context, state) {
          final tab = state.uri.queryParameters['tab'] ?? 'login';
          return AuthScreen(initialTab: tab);
        },
      ),
      ShellRoute(
        builder: (context, state, child) => MainShell(child: child),
        routes: [
          GoRoute(
            path: '/home',
            builder: (context, state) => const HomeScreen(),
          ),
          GoRoute(
            path: '/explore',
            builder: (context, state) => const ExploreScreen(),
          ),
          GoRoute(
            path: '/record',
            builder: (context, state) {
              final scene = state.extra as SceneModel?;
              return RecordScreen(scene: scene);
            },
          ),
          GoRoute(
            path: '/notifications',
            builder: (context, state) => const NotificationsScreen(),
          ),
          GoRoute(
            path: '/profile/:userId',
            builder: (context, state) {
              final userId = state.pathParameters['userId']!;
              return ProfileScreen(userId: userId);
            },
          ),
        ],
      ),
      GoRoute(
        path: '/leaderboard',
        builder: (context, state) => const LeaderboardScreen(),
      ),
      GoRoute(
        path: '/battle',
        builder: (context, state) => const BattleScreen(),
      ),
      GoRoute(
        path: '/badges',
        builder: (context, state) => const BadgesStatsScreen(),
      ),
      GoRoute(
        path: '/challenge',
        builder: (context, state) => const DailyChallengeScreen(),
      ),
      GoRoute(
        path: '/preview',
        builder: (context, state) {
          final data = state.extra as Map<String, dynamic>?;
          return PreviewPublishScreen(
            videoPath: data?['videoPath'],
            scene: data?['scene'],
          );
        },
      ),
      GoRoute(
        path: '/scene/:sceneId',
        builder: (context, state) {
          final sceneId = state.pathParameters['sceneId']!;
          return SceneDetailScreen(sceneId: sceneId);
        },
      ),
    ],
  );
});
