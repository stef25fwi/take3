import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/models.dart';
import '../services/api_service.dart';
import '../services/mock_data.dart';

final apiServiceProvider = Provider<ApiService>((ref) => ApiService());

// ─── Auth Provider ────────────────────────────────────────────────────────────
class AuthNotifier extends StateNotifier<AuthState> {
  final ApiService _api;
  AuthNotifier(this._api) : super(const AuthState());

  Future<void> login(String email, String password) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final user = await _api.login(email, password);
      state = state.copyWith(isLoading: false, user: user, isAuthenticated: true);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> register(String username, String email, String password) async {
    state = state.copyWith(isLoading: true, error: null);
    try {
      final user = await _api.register(username, email, password);
      state = state.copyWith(isLoading: false, user: user, isAuthenticated: true);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  Future<void> logout() async {
    await _api.logout();
    state = const AuthState();
  }
}

class AuthState {
  final bool isLoading;
  final bool isAuthenticated;
  final UserModel? user;
  final String? error;

  const AuthState({
    this.isLoading = false,
    this.isAuthenticated = false,
    this.user,
    this.error,
  });

  AuthState copyWith({bool? isLoading, bool? isAuthenticated, UserModel? user, String? error}) {
    return AuthState(
      isLoading: isLoading ?? this.isLoading,
      isAuthenticated: isAuthenticated ?? this.isAuthenticated,
      user: user ?? this.user,
      error: error,
    );
  }
}

final authProvider = StateNotifierProvider<AuthNotifier, AuthState>(
  (ref) => AuthNotifier(ref.read(apiServiceProvider)),
);

// ─── Feed Provider ────────────────────────────────────────────────────────────
class FeedNotifier extends StateNotifier<FeedState> {
  final ApiService _api;
  FeedNotifier(this._api) : super(const FeedState()) {
    loadFeed();
  }

  Future<void> loadFeed() async {
    state = state.copyWith(isLoading: true);
    try {
      final scenes = await _api.getFeed();
      state = state.copyWith(isLoading: false, scenes: scenes);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  void toggleLike(String sceneId) {
    final scenes = state.scenes.map((s) {
      if (s.id == sceneId) {
        return s.copyWith(
          isLiked: !s.isLiked,
          likesCount: s.isLiked ? s.likesCount - 1 : s.likesCount + 1,
        );
      }
      return s;
    }).toList();
    state = state.copyWith(scenes: scenes);
    _api.likeScene(sceneId);
  }
}

class FeedState {
  final bool isLoading;
  final List<SceneModel> scenes;
  final String? error;

  const FeedState({this.isLoading = false, this.scenes = const [], this.error});

  FeedState copyWith({bool? isLoading, List<SceneModel>? scenes, String? error}) {
    return FeedState(
      isLoading: isLoading ?? this.isLoading,
      scenes: scenes ?? this.scenes,
      error: error,
    );
  }
}

final feedProvider = StateNotifierProvider<FeedNotifier, FeedState>(
  (ref) => FeedNotifier(ref.read(apiServiceProvider)),
);

// ─── Explore Provider ─────────────────────────────────────────────────────────
class ExploreNotifier extends StateNotifier<ExploreState> {
  final ApiService _api;
  ExploreNotifier(this._api) : super(const ExploreState()) {
    load();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true);
    try {
      final categories = await _api.getCategories();
      final scenes = await _api.getPopularScenes('all');
      state = state.copyWith(isLoading: false, categories: categories, scenes: scenes);
    } catch (e) {
      state = state.copyWith(isLoading: false);
    }
  }

  Future<void> selectCategory(String categoryId) async {
    state = state.copyWith(selectedCategory: categoryId, isLoading: true);
    final cat = state.categories.firstWhere(
      (c) => c.id == categoryId,
      orElse: () => state.categories.first,
    );
    final scenes = await _api.getPopularScenes(cat.name);
    state = state.copyWith(scenes: scenes, isLoading: false);
  }
}

class ExploreState {
  final bool isLoading;
  final List<CategoryModel> categories;
  final List<SceneModel> scenes;
  final String? selectedCategory;

  const ExploreState({
    this.isLoading = false,
    this.categories = const [],
    this.scenes = const [],
    this.selectedCategory,
  });

  ExploreState copyWith({
    bool? isLoading,
    List<CategoryModel>? categories,
    List<SceneModel>? scenes,
    String? selectedCategory,
  }) {
    return ExploreState(
      isLoading: isLoading ?? this.isLoading,
      categories: categories ?? this.categories,
      scenes: scenes ?? this.scenes,
      selectedCategory: selectedCategory ?? this.selectedCategory,
    );
  }
}

final exploreProvider = StateNotifierProvider<ExploreNotifier, ExploreState>(
  (ref) => ExploreNotifier(ref.read(apiServiceProvider)),
);

// ─── Leaderboard Provider ─────────────────────────────────────────────────────
class LeaderboardNotifier extends StateNotifier<LeaderboardState> {
  final ApiService _api;
  LeaderboardNotifier(this._api) : super(const LeaderboardState()) {
    load('day');
  }

  Future<void> load(String period) async {
    state = state.copyWith(isLoading: true, period: period);
    try {
      final entries = await _api.getLeaderboard(period);
      state = state.copyWith(isLoading: false, entries: entries);
    } catch (e) {
      state = state.copyWith(isLoading: false);
    }
  }
}

class LeaderboardState {
  final bool isLoading;
  final List<LeaderboardEntry> entries;
  final String period;

  const LeaderboardState({
    this.isLoading = false,
    this.entries = const [],
    this.period = 'day',
  });

  LeaderboardState copyWith({bool? isLoading, List<LeaderboardEntry>? entries, String? period}) {
    return LeaderboardState(
      isLoading: isLoading ?? this.isLoading,
      entries: entries ?? this.entries,
      period: period ?? this.period,
    );
  }
}

final leaderboardProvider = StateNotifierProvider<LeaderboardNotifier, LeaderboardState>(
  (ref) => LeaderboardNotifier(ref.read(apiServiceProvider)),
);

// ─── Duel Provider ────────────────────────────────────────────────────────────
class DuelNotifier extends StateNotifier<DuelState> {
  final ApiService _api;
  DuelNotifier(this._api) : super(const DuelState()) {
    load();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true);
    try {
      final duel = await _api.getCurrentDuel();
      state = state.copyWith(isLoading: false, duel: duel);
    } catch (e) {
      state = state.copyWith(isLoading: false);
    }
  }

  Future<void> vote(int choice) async {
    if (state.duel == null) return;
    final updated = await _api.vote(state.duel!.id, choice);
    state = state.copyWith(duel: updated);
  }
}

class DuelState {
  final bool isLoading;
  final DuelModel? duel;

  const DuelState({this.isLoading = false, this.duel});

  DuelState copyWith({bool? isLoading, DuelModel? duel}) {
    return DuelState(isLoading: isLoading ?? this.isLoading, duel: duel ?? this.duel);
  }
}

final duelProvider = StateNotifierProvider<DuelNotifier, DuelState>(
  (ref) => DuelNotifier(ref.read(apiServiceProvider)),
);

// ─── Notifications Provider ───────────────────────────────────────────────────
final notificationsProvider = FutureProvider<List<NotificationModel>>((ref) async {
  final api = ref.read(apiServiceProvider);
  return api.getNotifications();
});

// ─── Daily Challenge Provider ─────────────────────────────────────────────────
final dailyChallengeProvider = FutureProvider<DailyChallengeModel>((ref) async {
  final api = ref.read(apiServiceProvider);
  return api.getDailyChallenge();
});

// ─── Profile Provider ─────────────────────────────────────────────────────────
class ProfileNotifier extends StateNotifier<ProfileState> {
  final ApiService _api;
  final String userId;

  ProfileNotifier(this._api, this.userId) : super(const ProfileState()) {
    load();
  }

  Future<void> load() async {
    state = state.copyWith(isLoading: true);
    try {
      final user = await _api.getProfile(userId);
      final scenes = await _api.getUserScenes(userId);
      state = state.copyWith(isLoading: false, user: user, scenes: scenes);
    } catch (e) {
      state = state.copyWith(isLoading: false);
    }
  }

  void toggleFollow() {
    if (state.user == null) return;
    final updated = state.user!.copyWith(
      isFollowing: !state.user!.isFollowing,
      followersCount: state.user!.isFollowing
          ? state.user!.followersCount - 1
          : state.user!.followersCount + 1,
    );
    state = state.copyWith(user: updated);
    _api.followUser(userId);
  }
}

class ProfileState {
  final bool isLoading;
  final UserModel? user;
  final List<SceneModel> scenes;

  const ProfileState({this.isLoading = false, this.user, this.scenes = const []});

  ProfileState copyWith({bool? isLoading, UserModel? user, List<SceneModel>? scenes}) {
    return ProfileState(
      isLoading: isLoading ?? this.isLoading,
      user: user ?? this.user,
      scenes: scenes ?? this.scenes,
    );
  }
}

final profileProvider = StateNotifierProvider.family<ProfileNotifier, ProfileState, String>(
  (ref, userId) => ProfileNotifier(ref.read(apiServiceProvider), userId),
);

// ─── Recording State ──────────────────────────────────────────────────────────
class RecordingNotifier extends StateNotifier<RecordingState> {
  RecordingNotifier() : super(const RecordingState());

  void setScene(SceneModel scene) => state = state.copyWith(scene: scene);
  void startRecording() => state = state.copyWith(isRecording: true, elapsed: 0);
  void updateElapsed(int sec) => state = state.copyWith(elapsed: sec);
  void stopRecording(String? path) => state = state.copyWith(
    isRecording: false,
    recordedPath: path,
  );
  void reset() => state = const RecordingState();
}

class RecordingState {
  final bool isRecording;
  final int elapsed;
  final String? recordedPath;
  final SceneModel? scene;

  const RecordingState({
    this.isRecording = false,
    this.elapsed = 0,
    this.recordedPath,
    this.scene,
  });

  RecordingState copyWith({
    bool? isRecording,
    int? elapsed,
    String? recordedPath,
    SceneModel? scene,
  }) {
    return RecordingState(
      isRecording: isRecording ?? this.isRecording,
      elapsed: elapsed ?? this.elapsed,
      recordedPath: recordedPath ?? this.recordedPath,
      scene: scene ?? this.scene,
    );
  }
}

final recordingProvider = StateNotifierProvider<RecordingNotifier, RecordingState>(
  (ref) => RecordingNotifier(),
);
