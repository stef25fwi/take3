import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';

class ExploreScreen extends ConsumerStatefulWidget {
  const ExploreScreen({super.key});

  @override
  ConsumerState<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends ConsumerState<ExploreScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final exploreState = ref.watch(exploreProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            // Search header
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 0),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _searchCtrl,
                        style: const TextStyle(color: AppColors.white),
                        decoration: InputDecoration(
                          hintText: 'Rechercher une scène...',
                          prefixIcon: const Icon(Icons.search, color: AppColors.grey),
                          suffixIcon: const Icon(Icons.emoji_emotions_outlined, color: AppColors.grey),
                          contentPadding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                      ),
                    ),
                    const SizedBox(width: 10),
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppColors.surfaceLight,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: const Icon(Icons.tune_rounded, color: AppColors.white, size: 20),
                    ),
                  ],
                ),
              ),
            ),

            // Categories
            SliverToBoxAdapter(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Padding(
                    padding: EdgeInsets.fromLTRB(16, 20, 16, 12),
                    child: Text(
                      'Catégories',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w700,
                        color: AppColors.white,
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 44,
                    child: ListView.builder(
                      scrollDirection: Axis.horizontal,
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      itemCount: exploreState.categories.length,
                      itemBuilder: (_, i) {
                        final cat = exploreState.categories[i];
                        final isSelected = exploreState.selectedCategory == cat.id;
                        return Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: CategoryChip(
                            category: cat,
                            isSelected: isSelected,
                            onTap: () => ref.read(exploreProvider.notifier)
                                .selectCategory(isSelected ? '' : cat.id),
                          ),
                        );
                      },
                    ),
                  ),
                ],
              ),
            ),

            // Popular scenes
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 20, 16, 12),
                child: SectionHeader(
                  title: 'Scènes populaires',
                  actionLabel: 'Voir tout',
                  onAction: () {},
                ),
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    if (exploreState.isLoading) {
                      return const ShimmerBox(width: double.infinity, height: 150);
                    }
                    final scene = exploreState.scenes[i % exploreState.scenes.length];
                    return SceneCard(
                      scene: scene,
                      onTap: () => context.go('/scene/${scene.id}'),
                    );
                  },
                  childCount: exploreState.isLoading ? 6 : exploreState.scenes.length,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.85,
                ),
              ),
            ),

            // New scenes
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(16, 24, 16, 12),
                child: SectionHeader(
                  title: 'Nouvelles scènes',
                  actionLabel: 'Voir tout',
                  onAction: () {},
                ),
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 20),
              sliver: SliverGrid(
                delegate: SliverChildBuilderDelegate(
                  (context, i) {
                    final scene = MockData.scenes[i % MockData.scenes.length];
                    return SceneCard(
                      scene: scene,
                      onTap: () => context.go('/scene/${scene.id}'),
                    );
                  },
                  childCount: 4,
                ),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 0.85,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
