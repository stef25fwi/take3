import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../models/models.dart';

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifsAsync = ref.watch(notificationsProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
          onPressed: () => context.go('/home'),
        ),
        title: const Text('Notifications'),
        centerTitle: true,
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text(
              'Tout lire',
              style: TextStyle(color: AppColors.cyan, fontSize: 13),
            ),
          ),
        ],
      ),
      body: notifsAsync.when(
        loading: () => ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: 5,
          itemBuilder: (_, __) => const Padding(
            padding: EdgeInsets.only(bottom: 12),
            child: ShimmerBox(width: double.infinity, height: 70, borderRadius: 14),
          ),
        ),
        error: (_, __) => const Center(
          child: Text('Erreur de chargement', style: TextStyle(color: AppColors.grey)),
        ),
        data: (notifications) => ListView.builder(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
          itemCount: notifications.length,
          itemBuilder: (context, i) {
            return _NotifCard(
              notif: notifications[i],
              onTap: () => _handleNotifTap(context, notifications[i]),
            );
          },
        ),
      ),
    );
  }

  void _handleNotifTap(BuildContext context, NotificationModel notif) {
    switch (notif.type) {
      case NotificationType.like:
      case NotificationType.comment:
        context.go('/home');
        break;
      case NotificationType.duel:
        context.go('/battle');
        break;
      case NotificationType.achievement:
        context.go('/badges');
        break;
      case NotificationType.system:
        break;
    }
  }
}

class _NotifCard extends StatelessWidget {
  final NotificationModel notif;
  final VoidCallback onTap;

  const _NotifCard({required this.notif, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: notif.isRead ? AppColors.cardDark : AppColors.surfaceLight,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: notif.isRead ? AppColors.border : AppColors.purple.withOpacity(0.3),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Icon or avatar
            notif.avatarUrl != null
                ? Stack(
                    children: [
                      UserAvatar(url: notif.avatarUrl, size: 44),
                      Positioned(
                        bottom: 0,
                        right: 0,
                        child: _notifIconSmall(notif.type),
                      ),
                    ],
                  )
                : NotifIcon(type: notif.type),

            const SizedBox(width: 12),

            // Content
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    notif.message,
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: notif.isRead ? FontWeight.w500 : FontWeight.w700,
                      color: AppColors.white,
                      height: 1.3,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    notif.subMessage,
                    style: const TextStyle(fontSize: 12, color: AppColors.grey),
                  ),
                ],
              ),
            ),

            const SizedBox(width: 8),

            // Action button / unread dot
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                if (!notif.isRead)
                  Container(
                    width: 8,
                    height: 8,
                    decoration: const BoxDecoration(
                      color: AppColors.cyan,
                      shape: BoxShape.circle,
                    ),
                  ),
                const SizedBox(height: 6),
                if (_hasAction(notif.type))
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.yellow.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppColors.yellow.withOpacity(0.3)),
                    ),
                    child: Text(
                      _actionLabel(notif.type),
                      style: const TextStyle(
                        fontSize: 11,
                        color: AppColors.yellow,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _notifIconSmall(NotificationType type) {
    IconData icon;
    Color color;
    switch (type) {
      case NotificationType.like:
        icon = Icons.favorite;
        color = AppColors.red;
        break;
      case NotificationType.comment:
        icon = Icons.chat_bubble;
        color = AppColors.cyan;
        break;
      case NotificationType.duel:
        icon = Icons.sports_mma;
        color = AppColors.purple;
        break;
      case NotificationType.achievement:
        icon = Icons.emoji_events;
        color = AppColors.yellow;
        break;
      case NotificationType.system:
        icon = Icons.info;
        color = AppColors.grey;
        break;
    }
    return Container(
      width: 18,
      height: 18,
      decoration: BoxDecoration(
        color: color,
        shape: BoxShape.circle,
        border: Border.all(color: AppColors.dark, width: 1.5),
      ),
      child: Icon(icon, color: Colors.white, size: 10),
    );
  }

  bool _hasAction(NotificationType type) =>
      type == NotificationType.duel || type == NotificationType.achievement;

  String _actionLabel(NotificationType type) {
    switch (type) {
      case NotificationType.duel:
        return 'Voter →';
      case NotificationType.achievement:
        return 'Voir →';
      default:
        return '';
    }
  }
}
