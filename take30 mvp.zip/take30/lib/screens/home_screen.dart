import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';

class HomeScreen extends ConsumerWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final feedState = ref.watch(feedProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      body: CustomScrollView(
        slivers: [
          // App Bar
          SliverAppBar(
            backgroundColor: AppColors.navy,
            floating: true,
            pinned: false,
            elevation: 0,
            title: ShaderMask(
              shaderCallback: (b) => AppColors.primaryGradient.createShader(b),
              child: const Text(
                'Take30',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: Colors.white,
                  letterSpacing: -0.5,
                ),
              ),
            ),
            actions: [
              // Leaderboard shortcut
              IconButton(
                icon: const Icon(Icons.emoji_events_rounded, color: AppColors.yellow),
                onPressed: () => context.go('/leaderboard'),
              ),
              // Challenge shortcut
              IconButton(
                icon: const Icon(Icons.local_fire_department_rounded, color: AppColors.red),
                onPressed: () => context.go('/challenge'),
              ),
              IconButton(
                icon: const UserAvatar(url: 'https://i.pravatar.cc/150?img=47', size: 32),
                onPressed: () => context.go('/profile/u1'),
              ),
              const SizedBox(width: 8),
            ],
          ),

          // Daily Challenge Banner
          SliverToBoxAdapter(
            child: GestureDetector(
              onTap: () => context.go('/challenge'),
              child: Container(
                margin: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                    colors: [Color(0xFF1A1030), Color(0xFF0D1626)],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: AppColors.purple.withOpacity(0.4)),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                        color: AppColors.red.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Center(
                        child: Text('🔥', style: TextStyle(fontSize: 22)),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text(
                            'Défi du Jour',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w700,
                              color: AppColors.yellow,
                            ),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            '"Tu m\'as trahi." — Relève le défi maintenant',
                            style: TextStyle(
                              fontSize: 12,
                              color: AppColors.greyLight,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.grey),
                  ],
                ),
              ),
            ),
          ),

          // Feed
          if (feedState.isLoading)
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (_, i) => const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 0),
                  child: ShimmerBox(width: double.infinity, height: 320, borderRadius: 16),
                ),
                childCount: 3,
              ),
            )
          else
            SliverList(
              delegate: SliverChildBuilderDelegate(
                (context, index) {
                  final scene = feedState.scenes[index];
                  return _FeedCard(
                    scene: scene,
                    onLike: () => ref.read(feedProvider.notifier).toggleLike(scene.id),
                    onProfile: () => context.go('/profile/${scene.author.id}'),
                    onShare: () {},
                    onTap: () => context.go('/scene/${scene.id}'),
                  );
                },
                childCount: feedState.scenes.length,
              ),
            ),

          const SliverToBoxAdapter(child: SizedBox(height: 20)),
        ],
      ),
    );
  }
}

class _FeedCard extends StatelessWidget {
  final dynamic scene;
  final VoidCallback onLike;
  final VoidCallback onProfile;
  final VoidCallback onShare;
  final VoidCallback onTap;

  const _FeedCard({
    required this.scene,
    required this.onLike,
    required this.onProfile,
    required this.onShare,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 16, 16, 0),
      decoration: BoxDecoration(
        color: AppColors.cardDark,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Thumbnail
          GestureDetector(
            onTap: onTap,
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      scene.thumbnailUrl,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => Container(color: AppColors.surface),
                    ),
                    const DecoratedBox(
                      decoration: BoxDecoration(gradient: AppColors.darkOverlay),
                    ),
                    // Play button
                    Center(
                      child: Container(
                        width: 56,
                        height: 56,
                        decoration: BoxDecoration(
                          color: Colors.black45,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white38, width: 2),
                        ),
                        child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 32),
                      ),
                    ),
                    // Duration badge
                    Positioned(
                      top: 10,
                      right: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.black54,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          scene.durationFormatted,
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                    // Category badge
                    Positioned(
                      top: 10,
                      left: 10,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: AppColors.purple.withOpacity(0.8),
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Text(
                          scene.category,
                          style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          // Info row
          Padding(
            padding: const EdgeInsets.all(14),
            child: Row(
              children: [
                GestureDetector(
                  onTap: onProfile,
                  child: UserAvatar(url: scene.author.avatarUrl, size: 38),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      GestureDetector(
                        onTap: onProfile,
                        child: Row(
                          children: [
                            Text(
                              scene.author.username,
                              style: const TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w700,
                                color: AppColors.white,
                              ),
                            ),
                            if (scene.author.isVerified) ...[
                              const SizedBox(width: 4),
                              const Icon(Icons.verified, size: 14, color: AppColors.cyan),
                            ],
                          ],
                        ),
                      ),
                      Text(
                        scene.title,
                        style: const TextStyle(fontSize: 13, color: AppColors.greyLight),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),

          // Actions
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
            child: Row(
              children: [
                _ActionBtn(
                  icon: scene.isLiked ? Icons.favorite : Icons.favorite_border,
                  color: scene.isLiked ? AppColors.red : AppColors.grey,
                  count: MockData.formatCount(scene.likesCount),
                  onTap: onLike,
                ),
                const SizedBox(width: 16),
                _ActionBtn(
                  icon: Icons.comment_outlined,
                  color: AppColors.grey,
                  count: MockData.formatCount(scene.commentsCount),
                  onTap: () {},
                ),
                const SizedBox(width: 16),
                _ActionBtn(
                  icon: Icons.share_outlined,
                  color: AppColors.grey,
                  count: MockData.formatCount(scene.sharesCount),
                  onTap: onShare,
                ),
                const Spacer(),
                // Battle shortcut
                GestureDetector(
                  onTap: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const SizedBox()),
                  ),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                    decoration: BoxDecoration(
                      gradient: AppColors.primaryGradient,
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: const Text(
                      'Jouer',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w700,
                        color: AppColors.navy,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final IconData icon;
  final Color color;
  final String count;
  final VoidCallback onTap;

  const _ActionBtn({
    required this.icon,
    required this.color,
    required this.count,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Row(
        children: [
          Icon(icon, size: 20, color: color),
          const SizedBox(width: 4),
          Text(count, style: TextStyle(fontSize: 13, color: color, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }
}
