import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';

class AuthScreen extends ConsumerStatefulWidget {
  final String initialTab;
  const AuthScreen({super.key, this.initialTab = 'login'});

  @override
  ConsumerState<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends ConsumerState<AuthScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;
  final _emailCtrl = TextEditingController();
  final _passwordCtrl = TextEditingController();
  final _usernameCtrl = TextEditingController();
  bool _obscure = true;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(
      length: 2,
      vsync: this,
      initialIndex: widget.initialTab == 'register' ? 1 : 0,
    );
  }

  @override
  void dispose() {
    _tabs.dispose();
    _emailCtrl.dispose();
    _passwordCtrl.dispose();
    _usernameCtrl.dispose();
    super.dispose();
  }

  void _submit() async {
    final auth = ref.read(authProvider.notifier);
    if (_tabs.index == 0) {
      await auth.login(_emailCtrl.text, _passwordCtrl.text);
    } else {
      await auth.register(_usernameCtrl.text, _emailCtrl.text, _passwordCtrl.text);
    }
    if (mounted) {
      final state = ref.read(authProvider);
      if (state.isAuthenticated) context.go('/home');
    }
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            children: [
              const SizedBox(height: 40),

              // Logo
              ShaderMask(
                shaderCallback: (bounds) =>
                    AppColors.primaryGradient.createShader(bounds),
                child: const Text(
                  'Take30',
                  style: TextStyle(
                    fontSize: 40,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    letterSpacing: -1.5,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              const Text(
                'Prouve ton talent en 30 secondes',
                style: TextStyle(fontSize: 14, color: AppColors.grey),
              ),

              const SizedBox(height: 40),

              // Tab bar
              Container(
                height: 48,
                decoration: BoxDecoration(
                  color: AppColors.surfaceLight,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: TabBar(
                  controller: _tabs,
                  indicator: BoxDecoration(
                    color: AppColors.yellow,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  indicatorSize: TabBarIndicatorSize.tab,
                  labelColor: AppColors.navy,
                  unselectedLabelColor: AppColors.grey,
                  labelStyle: const TextStyle(fontWeight: FontWeight.w700),
                  dividerColor: Colors.transparent,
                  tabs: const [
                    Tab(text: 'Connexion'),
                    Tab(text: 'Inscription'),
                  ],
                ),
              ),

              const SizedBox(height: 32),

              // Tab content
              AnimatedBuilder(
                animation: _tabs,
                builder: (_, __) => Column(
                  children: [
                    if (_tabs.index == 1) ...[
                      _buildInput(
                        controller: _usernameCtrl,
                        label: 'Nom d\'utilisateur',
                        hint: '@monpseudo',
                        icon: Icons.person_outline,
                      ),
                      const SizedBox(height: 16),
                    ],
                    _buildInput(
                      controller: _emailCtrl,
                      label: 'Email',
                      hint: 'ton@email.com',
                      icon: Icons.email_outlined,
                      keyboardType: TextInputType.emailAddress,
                    ),
                    const SizedBox(height: 16),
                    _buildInput(
                      controller: _passwordCtrl,
                      label: 'Mot de passe',
                      hint: '••••••••',
                      icon: Icons.lock_outline,
                      isPassword: true,
                    ),
                  ],
                ),
              ),

              if (authState.error != null) ...[
                const SizedBox(height: 12),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: AppColors.red.withOpacity(0.3)),
                  ),
                  child: Text(
                    authState.error!,
                    style: const TextStyle(color: AppColors.red, fontSize: 13),
                  ),
                ),
              ],

              const SizedBox(height: 24),

              PrimaryButton(
                label: _tabs.index == 0 ? 'Se connecter' : 'Créer un compte',
                isLoading: authState.isLoading,
                onTap: _submit,
              ),

              const SizedBox(height: 16),

              // Quick demo access
              TextButton(
                onPressed: () {
                  _emailCtrl.text = 'demo@take30.app';
                  _passwordCtrl.text = 'demo1234';
                  _submit();
                },
                child: const Text(
                  'Accès démo rapide →',
                  style: TextStyle(color: AppColors.cyan, fontSize: 14),
                ),
              ),

              const SizedBox(height: 24),

              // Back
              TextButton(
                onPressed: () => context.go('/onboarding'),
                child: const Text(
                  '← Retour',
                  style: TextStyle(color: AppColors.grey, fontSize: 14),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInput({
    required TextEditingController controller,
    required String label,
    required String hint,
    required IconData icon,
    bool isPassword = false,
    TextInputType? keyboardType,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: AppColors.greyLight,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: controller,
          obscureText: isPassword && _obscure,
          keyboardType: keyboardType,
          style: const TextStyle(color: AppColors.white),
          decoration: InputDecoration(
            hintText: hint,
            prefixIcon: Icon(icon, color: AppColors.grey, size: 20),
            suffixIcon: isPassword
                ? IconButton(
                    icon: Icon(
                      _obscure ? Icons.visibility_off : Icons.visibility,
                      color: AppColors.grey,
                      size: 20,
                    ),
                    onPressed: () => setState(() => _obscure = !_obscure),
                  )
                : null,
          ),
        ),
      ],
    );
  }
}
