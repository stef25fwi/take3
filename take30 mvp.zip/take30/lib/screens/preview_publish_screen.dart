import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../models/models.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';

class PreviewPublishScreen extends ConsumerStatefulWidget {
  final String? videoPath;
  final SceneModel? scene;

  const PreviewPublishScreen({super.key, this.videoPath, this.scene});

  @override
  ConsumerState<PreviewPublishScreen> createState() => _PreviewPublishScreenState();
}

class _PreviewPublishScreenState extends ConsumerState<PreviewPublishScreen> {
  final _titleCtrl = TextEditingController();
  String _selectedCategory = 'Drame';
  List<String> _selectedTags = ['drame'];
  bool _isPublishing = false;

  @override
  void initState() {
    super.initState();
    _titleCtrl.text = widget.scene?.title ?? 'Annonce d\'une mauvaise nouvelle';
    _selectedCategory = widget.scene?.category ?? 'Drame';
    _selectedTags = widget.scene?.tags ?? ['drame'];
  }

  @override
  void dispose() {
    _titleCtrl.dispose();
    super.dispose();
  }

  Future<void> _publish() async {
    setState(() => _isPublishing = true);
    await Future.delayed(const Duration(seconds: 2));
    if (mounted) {
      setState(() => _isPublishing = false);
      _showSuccessDialog();
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => Dialog(
        backgroundColor: AppColors.cardDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        child: Padding(
          padding: const EdgeInsets.all(28),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('🎉', style: TextStyle(fontSize: 48)),
              const SizedBox(height: 16),
              const Text(
                'Publié !',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: AppColors.white),
              ),
              const SizedBox(height: 8),
              const Text(
                'Ta scène est maintenant visible par tous. Bonne chance !',
                style: TextStyle(color: AppColors.grey, fontSize: 14),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              PrimaryButton(
                label: 'Voir mon profil',
                onTap: () {
                  Navigator.pop(context);
                  context.go('/profile/u1');
                },
              ),
              const SizedBox(height: 12),
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                  context.go('/home');
                },
                child: const Text(
                  'Retour à l\'accueil',
                  style: TextStyle(color: AppColors.grey),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        leading: IconButton(
          icon: const Icon(Icons.close, color: AppColors.white),
          onPressed: () => context.go('/record'),
        ),
        actions: [
          TextButton(
            onPressed: () {},
            child: const Text(
              'Modifier',
              style: TextStyle(color: AppColors.cyan, fontWeight: FontWeight.w600),
            ),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Video preview
            ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: AspectRatio(
                aspectRatio: 16 / 9,
                child: Stack(
                  children: [
                    // Thumbnail
                    Positioned.fill(
                      child: Image.network(
                        widget.scene?.thumbnailUrl ??
                            'https://images.unsplash.com/photo-1542513217-0b0eeea7f7bc?w=400',
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(color: AppColors.cardDark),
                      ),
                    ),
                    const Positioned.fill(
                      child: DecoratedBox(
                        decoration: BoxDecoration(gradient: AppColors.darkOverlay),
                      ),
                    ),
                    // Play button
                    Center(
                      child: Container(
                        width: 60,
                        height: 60,
                        decoration: BoxDecoration(
                          color: Colors.black45,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white38, width: 2),
                        ),
                        child: const Icon(Icons.play_arrow_rounded, color: Colors.white, size: 36),
                      ),
                    ),
                    // Tags
                    Positioned(
                      bottom: 12,
                      left: 12,
                      child: Row(
                        children: [
                          _TagBadge(label: _selectedCategory),
                          const SizedBox(width: 6),
                          const _TagBadge(label: 'Annonce'),
                          const SizedBox(width: 6),
                          const _TagBadge(label: 'Solo'),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 20),

            // Title field
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Titre',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.greyLight,
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: _titleCtrl,
                  style: const TextStyle(color: AppColors.white),
                  decoration: const InputDecoration(hintText: 'Titre de ta scène...'),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Category selector
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Catégorie',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.greyLight,
                  ),
                ),
                const SizedBox(height: 10),
                Wrap(
                  spacing: 8,
                  children: MockData.categories.map((cat) {
                    final isSelected = _selectedCategory == cat.name;
                    return GestureDetector(
                      onTap: () => setState(() => _selectedCategory = cat.name),
                      child: AnimatedContainer(
                        duration: const Duration(milliseconds: 150),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                        decoration: BoxDecoration(
                          color: isSelected ? AppColors.yellow.withOpacity(0.15) : AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: isSelected ? AppColors.yellow : AppColors.border,
                          ),
                        ),
                        child: Text(
                          '${cat.emoji} ${cat.name}',
                          style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w600,
                            color: isSelected ? AppColors.yellow : AppColors.white,
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ],
            ),

            const SizedBox(height: 32),

            // Publish button
            PrimaryButton(
              label: 'Publier',
              isLoading: _isPublishing,
              onTap: _publish,
            ),

            const SizedBox(height: 12),

            SecondaryButton(
              label: 'Recommencer',
              onTap: () => context.go('/record'),
            ),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _TagBadge extends StatelessWidget {
  final String label;
  const _TagBadge({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: AppColors.purple.withOpacity(0.7),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(
        label,
        style: const TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600),
      ),
    );
  }
}
