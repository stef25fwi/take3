import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';
import '../models/models.dart';

class BadgesStatsScreen extends ConsumerWidget {
  const BadgesStatsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = MockData.users[0];

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
          onPressed: () => context.go('/profile/u1'),
        ),
        title: const Text('Badges & Stats'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Badges header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Tes badges',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w700,
                    color: AppColors.white,
                  ),
                ),
                GestureDetector(
                  onTap: () {},
                  child: const Text(
                    'Voir tout',
                    style: TextStyle(
                      fontSize: 14,
                      color: AppColors.cyan,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),

            const SizedBox(height: 16),

            // Badges row
            SizedBox(
              height: 100,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: MockData.badges.length,
                itemBuilder: (_, i) {
                  final badge = MockData.badges[i];
                  final Color badgeColor;
                  switch (badge.type) {
                    case BadgeType.gold:
                      badgeColor = AppColors.yellow;
                      break;
                    case BadgeType.silver:
                      badgeColor = AppColors.greyLight;
                      break;
                    case BadgeType.bronze:
                      badgeColor = const Color(0xFFCD7F32);
                      break;
                    case BadgeType.special:
                      badgeColor = AppColors.purple;
                      break;
                  }

                  return Container(
                    width: 80,
                    margin: const EdgeInsets.only(right: 12),
                    decoration: BoxDecoration(
                      color: AppColors.cardDark,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: badgeColor.withOpacity(0.35)),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(badge.emoji, style: const TextStyle(fontSize: 28)),
                        const SizedBox(height: 6),
                        Text(
                          badge.name,
                          style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: AppColors.greyLight,
                          ),
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),

            const SizedBox(height: 28),

            // Stats title
            const Text(
              'Stats',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: AppColors.white,
              ),
            ),

            const SizedBox(height: 16),

            // Stats list
            _StatRow(
              icon: Icons.play_circle_filled,
              iconColor: AppColors.cyan,
              label: 'Vues totales',
              value: MockData.formatCount(user.totalViews),
              onTap: () {},
            ),
            _StatRow(
              icon: Icons.thumb_up_alt_rounded,
              iconColor: AppColors.green,
              label: 'Taux d\'approbation',
              value: '${user.approvalRate.toInt()}%',
              valueColor: AppColors.green,
              onTap: () {},
              showBar: true,
              barValue: user.approvalRate / 100,
              barColor: AppColors.green,
            ),
            _StatRow(
              icon: Icons.share_rounded,
              iconColor: AppColors.yellow,
              label: 'Partages',
              value: MockData.formatCount(user.sharesCount),
              onTap: () {},
            ),
            _StatRow(
              icon: Icons.movie_filter_rounded,
              iconColor: AppColors.purple,
              label: 'Scènes jouées',
              value: '${user.scenesCount}',
              onTap: () {},
            ),

            const SizedBox(height: 28),

            // Performance chart placeholder
            const Text(
              'Évolution des vues',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppColors.white,
              ),
            ),
            const SizedBox(height: 12),
            Container(
              height: 160,
              decoration: BoxDecoration(
                color: AppColors.cardDark,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: AppColors.border),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text('30 derniers jours',
                            style: TextStyle(fontSize: 12, color: AppColors.grey)),
                        Row(
                          children: [
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: AppColors.cyan,
                                borderRadius: BorderRadius.circular(2),
                              ),
                            ),
                            const SizedBox(width: 4),
                            const Text('Vues',
                                style: TextStyle(fontSize: 11, color: AppColors.grey)),
                          ],
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Expanded(
                      child: _SimpleChart(),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 28),

            // Top scenes
            const Text(
              'Meilleures performances',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: AppColors.white,
              ),
            ),
            const SizedBox(height: 12),
            ...MockData.scenes.take(3).map((scene) => _TopSceneRow(scene: scene)),

            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}

class _StatRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final String label;
  final String value;
  final Color? valueColor;
  final VoidCallback onTap;
  final bool showBar;
  final double? barValue;
  final Color? barColor;

  const _StatRow({
    required this.icon,
    required this.iconColor,
    required this.label,
    required this.value,
    this.valueColor,
    required this.onTap,
    this.showBar = false,
    this.barValue,
    this.barColor,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: AppColors.cardDark,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: iconColor.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: iconColor, size: 20),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Text(
                    label,
                    style: const TextStyle(
                      fontSize: 15,
                      color: AppColors.greyLight,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
                Row(
                  children: [
                    Text(
                      value,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: valueColor ?? AppColors.white,
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Icon(Icons.arrow_forward_ios, size: 14, color: AppColors.grey),
                  ],
                ),
              ],
            ),
            if (showBar && barValue != null) ...[
              const SizedBox(height: 10),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: barValue,
                  backgroundColor: AppColors.surfaceLight,
                  valueColor: AlwaysStoppedAnimation(barColor ?? AppColors.cyan),
                  minHeight: 6,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _SimpleChart extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // Fake chart bars
    final data = [0.3, 0.5, 0.4, 0.7, 0.6, 0.8, 0.65, 0.9, 0.75, 0.85, 0.7, 1.0];
    return Row(
      crossAxisAlignment: CrossAxisAlignment.end,
      children: data.map((v) {
        return Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 2),
            child: AnimatedContainer(
              duration: Duration(milliseconds: 300 + (data.indexOf(v) * 60)),
              curve: Curves.easeOut,
              height: v * 80,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [AppColors.cyan.withOpacity(0.4), AppColors.cyan],
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                ),
                borderRadius: const BorderRadius.vertical(top: Radius.circular(3)),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }
}

class _TopSceneRow extends StatelessWidget {
  final dynamic scene;
  const _TopSceneRow({required this.scene});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.cardDark,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(8),
            child: SizedBox(
              width: 64,
              height: 48,
              child: Image.network(
                scene.thumbnailUrl,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: AppColors.surface),
              ),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  scene.title,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: AppColors.white,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Row(
                  children: [
                    const Icon(Icons.favorite, size: 11, color: AppColors.red),
                    const SizedBox(width: 3),
                    Text(
                      MockData.formatCount(scene.likesCount),
                      style: const TextStyle(fontSize: 11, color: AppColors.grey),
                    ),
                    const SizedBox(width: 10),
                    const Icon(Icons.remove_red_eye_outlined, size: 11, color: AppColors.cyan),
                    const SizedBox(width: 3),
                    Text(
                      MockData.formatCount(scene.viewsCount),
                      style: const TextStyle(fontSize: 11, color: AppColors.grey),
                    ),
                    const SizedBox(width: 10),
                    const Icon(Icons.share_outlined, size: 11, color: AppColors.yellow),
                    const SizedBox(width: 3),
                    Text(
                      MockData.formatCount(scene.sharesCount),
                      style: const TextStyle(fontSize: 11, color: AppColors.grey),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
