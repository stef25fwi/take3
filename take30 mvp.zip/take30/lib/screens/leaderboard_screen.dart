import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';

class LeaderboardScreen extends ConsumerWidget {
  const LeaderboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(leaderboardProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
          onPressed: () => context.go('/home'),
        ),
        title: const Text('Classement'),
        centerTitle: true,
      ),
      body: Column(
        children: [
          // Period tabs
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Row(
              children: [
                _PeriodTab(
                  label: 'Jour',
                  isSelected: state.period == 'day',
                  onTap: () => ref.read(leaderboardProvider.notifier).load('day'),
                ),
                const SizedBox(width: 8),
                _PeriodTab(
                  label: 'Semaine',
                  isSelected: state.period == 'week',
                  onTap: () => ref.read(leaderboardProvider.notifier).load('week'),
                ),
                const SizedBox(width: 8),
                _PeriodTab(
                  label: 'Mois',
                  isSelected: state.period == 'month',
                  onTap: () => ref.read(leaderboardProvider.notifier).load('month'),
                ),
                const SizedBox(width: 8),
                _PeriodTab(
                  label: 'Global',
                  isSelected: state.period == 'global',
                  onTap: () => ref.read(leaderboardProvider.notifier).load('global'),
                ),
              ],
            ),
          ),

          // Top 3 podium
          if (!state.isLoading && state.entries.length >= 3)
            _Podium(entries: state.entries.take(3).toList()),

          const SizedBox(height: 8),

          // List from rank 4+
          Expanded(
            child: state.isLoading
                ? const Center(child: CircularProgressIndicator(color: AppColors.yellow))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    itemCount: state.entries.length > 3 ? state.entries.length - 3 : 0,
                    itemBuilder: (_, i) {
                      final entry = state.entries[i + 3];
                      return _LeaderboardRow(
                        entry: entry,
                        onTap: () => context.go('/profile/${entry.user.id}'),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }
}

class _PeriodTab extends StatelessWidget {
  final String label;
  final bool isSelected;
  final VoidCallback onTap;

  const _PeriodTab({required this.label, required this.isSelected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isSelected ? AppColors.yellow : AppColors.surfaceLight,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Text(
          label,
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w600,
            color: isSelected ? AppColors.navy : AppColors.grey,
          ),
        ),
      ),
    );
  }
}

class _Podium extends StatelessWidget {
  final List<dynamic> entries;
  const _Podium({required this.entries});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          // 2nd
          Expanded(
            child: _PodiumItem(entry: entries[1], height: 90, medal: '🥈'),
          ),
          const SizedBox(width: 8),
          // 1st
          Expanded(
            flex: 1,
            child: _PodiumItem(entry: entries[0], height: 110, medal: '🥇'),
          ),
          const SizedBox(width: 8),
          // 3rd
          Expanded(
            child: _PodiumItem(entry: entries[2], height: 70, medal: '🥉'),
          ),
        ],
      ),
    );
  }
}

class _PodiumItem extends StatelessWidget {
  final dynamic entry;
  final double height;
  final String medal;

  const _PodiumItem({required this.entry, required this.height, required this.medal});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text(medal, style: const TextStyle(fontSize: 24)),
        const SizedBox(height: 6),
        UserAvatar(url: entry.user.avatarUrl, size: 48, showBorder: true),
        const SizedBox(height: 6),
        Text(
          entry.user.username,
          style: const TextStyle(
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: AppColors.white,
          ),
          textAlign: TextAlign.center,
          overflow: TextOverflow.ellipsis,
        ),
        const SizedBox(height: 2),
        Text(
          entry.scoreLabel,
          style: const TextStyle(fontSize: 11, color: AppColors.yellow),
        ),
        const SizedBox(height: 8),
        Container(
          height: height,
          decoration: BoxDecoration(
            color: entry.rank == 1 ? AppColors.yellow.withOpacity(0.15) : AppColors.surfaceLight,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(8)),
            border: Border.all(
              color: entry.rank == 1 ? AppColors.yellow.withOpacity(0.3) : AppColors.border,
            ),
          ),
          child: Center(
            child: Text(
              '#${entry.rank}',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w800,
                color: entry.rank == 1 ? AppColors.yellow : AppColors.grey,
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class _LeaderboardRow extends StatelessWidget {
  final dynamic entry;
  final VoidCallback onTap;

  const _LeaderboardRow({required this.entry, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        decoration: BoxDecoration(
          color: AppColors.cardDark,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            SizedBox(
              width: 28,
              child: Text(
                '${entry.rank}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w700,
                  color: AppColors.grey,
                ),
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(width: 12),
            UserAvatar(url: entry.user.avatarUrl, size: 40),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        entry.user.username,
                        style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: AppColors.white,
                        ),
                      ),
                      if (entry.user.isVerified) ...[
                        const SizedBox(width: 4),
                        const Icon(Icons.verified, size: 14, color: AppColors.cyan),
                      ],
                    ],
                  ),
                  // Badges row (mock)
                  Row(
                    children: List.generate(
                      2,
                      (_) => const Padding(
                        padding: EdgeInsets.only(right: 3),
                        child: Text('⭐', style: TextStyle(fontSize: 11)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Text(
              entry.scoreLabel,
              style: const TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w700,
                color: AppColors.yellow,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
