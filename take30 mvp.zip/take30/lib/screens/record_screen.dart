import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../models/models.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';

class RecordScreen extends ConsumerStatefulWidget {
  final SceneModel? scene;
  const RecordScreen({super.key, this.scene});

  @override
  ConsumerState<RecordScreen> createState() => _RecordScreenState();
}

class _RecordScreenState extends ConsumerState<RecordScreen>
    with SingleTickerProviderStateMixin {
  static const int maxSeconds = 30;
  
  bool _isRecording = false;
  bool _isPaused = false;
  int _elapsed = 0;
  Timer? _timer;
  late AnimationController _pulseController;
  SceneModel? _selectedScene;

  @override
  void initState() {
    super.initState();
    _selectedScene = widget.scene ?? MockData.scenes.first;
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _pulseController.dispose();
    super.dispose();
  }

  void _startRecording() {
    setState(() {
      _isRecording = true;
      _isPaused = false;
    });
    _pulseController.repeat(reverse: true);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() => _elapsed++);
      if (_elapsed >= maxSeconds) {
        _stopRecording();
      }
    });
  }

  void _pauseRecording() {
    _timer?.cancel();
    _pulseController.stop();
    setState(() => _isPaused = true);
  }

  void _resumeRecording() {
    _pulseController.repeat(reverse: true);
    setState(() => _isPaused = false);
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      setState(() => _elapsed++);
      if (_elapsed >= maxSeconds) _stopRecording();
    });
  }

  void _stopRecording() {
    _timer?.cancel();
    _pulseController.stop();
    setState(() => _isRecording = false);
    
    // Navigate to preview
    context.go('/preview', extra: {
      'videoPath': 'mock_video_path',
      'scene': _selectedScene,
    });
  }

  void _reset() {
    _timer?.cancel();
    _pulseController.stop();
    setState(() {
      _isRecording = false;
      _isPaused = false;
      _elapsed = 0;
    });
  }

  @override
  Widget build(BuildContext context) {
    final progress = _elapsed / maxSeconds;
    final remaining = maxSeconds - _elapsed;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Camera preview placeholder
          Positioned.fill(
            child: _isRecording
                ? Image.network(
                    _selectedScene?.thumbnailUrl ?? '',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                      color: const Color(0xFF0A0A0A),
                      child: const Center(
                        child: Icon(Icons.videocam_off, color: AppColors.grey, size: 48),
                      ),
                    ),
                  )
                : Container(
                    color: const Color(0xFF0A0A0A),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        const Icon(Icons.videocam, color: AppColors.grey, size: 64),
                        const SizedBox(height: 16),
                        const Text(
                          'Caméra',
                          style: TextStyle(color: AppColors.grey, fontSize: 16),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Requiert flutter_camera plugin',
                          style: TextStyle(
                            color: AppColors.grey.withOpacity(0.5),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
          ),

          // Dark overlay at top
          Positioned(
            top: 0,
            left: 0,
            right: 0,
            height: 200,
            child: DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.black.withOpacity(0.7), Colors.transparent],
                ),
              ),
            ),
          ),

          // Top bar
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  GestureDetector(
                    onTap: () => context.go('/home'),
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: Colors.black45,
                        shape: BoxShape.circle,
                      ),
                      child: const Icon(Icons.close, color: Colors.white, size: 20),
                    ),
                  ),
                  const Spacer(),
                  // Capture icon
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: Colors.black45,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.photo_camera_outlined, color: Colors.white, size: 20),
                  ),
                ],
              ),
            ),
          ),

          // Scene info (top)
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.only(top: 64),
              child: Column(
                children: [
                  if (_selectedScene != null)
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 40),
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(
                        _selectedScene!.title,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                ],
              ),
            ),
          ),

          // Timer display (center)
          if (_isRecording)
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    '${remaining.toString().padLeft(2, '0')}',
                    style: TextStyle(
                      fontSize: 80,
                      fontWeight: FontWeight.w900,
                      color: remaining <= 5 ? AppColors.red : Colors.white,
                      letterSpacing: -2,
                    ),
                  ),
                  const Text(
                    'secondes',
                    style: TextStyle(color: Colors.white54, fontSize: 14),
                  ),
                ],
              ),
            ),

          // Bottom controls
          Positioned(
            bottom: 0,
            left: 0,
            right: 0,
            child: Container(
              padding: const EdgeInsets.fromLTRB(24, 20, 24, 40),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topCenter,
                  colors: [Colors.black.withOpacity(0.9), Colors.transparent],
                ),
              ),
              child: Column(
                children: [
                  // Progress bar
                  if (_isRecording || _elapsed > 0) ...[
                    Row(
                      children: [
                        Text(
                          '00:${_elapsed.toString().padLeft(2, '0')}',
                          style: const TextStyle(color: Colors.white, fontSize: 12),
                        ),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 12),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(
                                value: progress,
                                backgroundColor: Colors.white24,
                                valueColor: AlwaysStoppedAnimation(
                                  remaining <= 5 ? AppColors.red : AppColors.yellow,
                                ),
                                minHeight: 4,
                              ),
                            ),
                          ),
                        ),
                        Text(
                          '00:$maxSeconds',
                          style: const TextStyle(color: Colors.white, fontSize: 12),
                        ),
                      ],
                    ),
                    const SizedBox(height: 20),
                  ],

                  // Controls row
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Scene select
                      _ControlBtn(
                        icon: Icons.movie_outlined,
                        label: 'Scènes',
                        onTap: _showSceneSelector,
                      ),

                      // Main record button
                      GestureDetector(
                        onTap: () {
                          if (!_isRecording && _elapsed == 0) {
                            _startRecording();
                          } else if (_isRecording && !_isPaused) {
                            _pauseRecording();
                          } else if (_isPaused) {
                            _resumeRecording();
                          }
                        },
                        child: AnimatedBuilder(
                          animation: _pulseController,
                          builder: (_, __) => Transform.scale(
                            scale: _isRecording && !_isPaused
                                ? 1 + _pulseController.value * 0.05
                                : 1,
                            child: Container(
                              width: 72,
                              height: 72,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 3),
                                boxShadow: _isRecording
                                    ? [
                                        BoxShadow(
                                          color: AppColors.red.withOpacity(0.5),
                                          blurRadius: 20,
                                          spreadRadius: 4,
                                        ),
                                      ]
                                    : [],
                              ),
                              child: Center(
                                child: AnimatedContainer(
                                  duration: const Duration(milliseconds: 200),
                                  width: _isRecording && !_isPaused ? 28 : 58,
                                  height: _isRecording && !_isPaused ? 28 : 58,
                                  decoration: BoxDecoration(
                                    color: _isRecording && !_isPaused ? AppColors.red : Colors.white,
                                    borderRadius: BorderRadius.circular(
                                      _isRecording && !_isPaused ? 6 : 100,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),

                      // Stop / flip
                      _ControlBtn(
                        icon: _isRecording ? Icons.stop_circle_outlined : Icons.flip_camera_android,
                        label: _isRecording ? 'Arrêter' : 'Retourner',
                        onTap: _isRecording ? _stopRecording : () {},
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showSceneSelector() {
    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.dark,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (_) => Column(
        children: [
          const SizedBox(height: 12),
          Container(
            width: 40,
            height: 4,
            decoration: BoxDecoration(
              color: AppColors.grey,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          const SizedBox(height: 16),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Text(
              'Choisir une scène',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: AppColors.white,
              ),
            ),
          ),
          const SizedBox(height: 16),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: MockData.scenes.length,
              itemBuilder: (_, i) {
                final scene = MockData.scenes[i];
                final isSelected = _selectedScene?.id == scene.id;
                return GestureDetector(
                  onTap: () {
                    setState(() => _selectedScene = scene);
                    Navigator.pop(context);
                  },
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: isSelected ? AppColors.yellow.withOpacity(0.1) : AppColors.surfaceLight,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isSelected ? AppColors.yellow : AppColors.border,
                      ),
                    ),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: SizedBox(
                            width: 60,
                            height: 45,
                            child: Image.network(
                              scene.thumbnailUrl,
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                scene.title,
                                style: const TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.white,
                                ),
                              ),
                              Text(
                                scene.category,
                                style: const TextStyle(fontSize: 12, color: AppColors.grey),
                              ),
                            ],
                          ),
                        ),
                        if (isSelected)
                          const Icon(Icons.check_circle, color: AppColors.yellow, size: 20),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _ControlBtn extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _ControlBtn({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: Colors.white12,
              shape: BoxShape.circle,
            ),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(color: Colors.white70, fontSize: 11)),
        ],
      ),
    );
  }
}
