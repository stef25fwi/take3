import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';
import '../models/models.dart';

class ProfileScreen extends ConsumerStatefulWidget {
  final String userId;
  const ProfileScreen({super.key, required this.userId});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final profileState = ref.watch(profileProvider(widget.userId));
    final isOwnProfile = widget.userId == 'u1';

    if (profileState.isLoading) {
      return const Scaffold(
        backgroundColor: AppColors.navy,
        body: Center(child: CircularProgressIndicator(color: AppColors.yellow)),
      );
    }

    final user = profileState.user ?? MockData.users[0];

    return Scaffold(
      backgroundColor: AppColors.navy,
      body: NestedScrollView(
        headerSliverBuilder: (context, innerBoxIsScrolled) => [
          SliverAppBar(
            backgroundColor: AppColors.navy,
            expandedHeight: 260,
            floating: false,
            pinned: true,
            leading: IconButton(
              icon: const Icon(Icons.arrow_back_ios, size: 20, color: AppColors.white),
              onPressed: () => context.go('/home'),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.search, color: AppColors.white),
                onPressed: () {},
              ),
              if (isOwnProfile)
                IconButton(
                  icon: const Icon(Icons.more_horiz, color: AppColors.white),
                  onPressed: () {},
                ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              collapseMode: CollapseMode.pin,
              background: _ProfileHeader(user: user, isOwnProfile: isOwnProfile),
            ),
          ),
        ],
        body: Column(
          children: [
            // Tab bar
            Container(
              color: AppColors.navy,
              child: TabBar(
                controller: _tabs,
                indicatorColor: AppColors.yellow,
                indicatorWeight: 2,
                labelColor: AppColors.yellow,
                unselectedLabelColor: AppColors.grey,
                labelStyle: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
                tabs: const [
                  Tab(text: 'Performances'),
                  Tab(text: 'Badges'),
                  Tab(text: 'Favoris'),
                ],
              ),
            ),

            // Tab content
            Expanded(
              child: TabBarView(
                controller: _tabs,
                children: [
                  _PerformancesTab(scenes: profileState.scenes),
                  _BadgesTab(badges: MockData.badges),
                  _PerformancesTab(scenes: profileState.scenes.reversed.toList()),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ProfileHeader extends ConsumerWidget {
  final UserModel user;
  final bool isOwnProfile;

  const _ProfileHeader({required this.user, required this.isOwnProfile});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Stack(
      children: [
        // Background gradient
        Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              colors: [Color(0xFF0D1626), Color(0xFF1A1035)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
        ),

        // Glow effect
        Positioned(
          top: -40,
          left: -40,
          child: Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: RadialGradient(
                colors: [AppColors.purple.withOpacity(0.2), Colors.transparent],
              ),
            ),
          ),
        ),

        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 60, 20, 20),
            child: Column(
              children: [
                // Avatar + info
                Row(
                  children: [
                    Stack(
                      children: [
                        UserAvatar(url: user.avatarUrl, size: 72, showBorder: true),
                        if (user.isVerified)
                          Positioned(
                            bottom: 2,
                            right: 2,
                            child: Container(
                              width: 20,
                              height: 20,
                              decoration: const BoxDecoration(
                                color: AppColors.cyan,
                                shape: BoxShape.circle,
                              ),
                              child: const Icon(Icons.check, size: 12, color: Colors.white),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                user.displayName,
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w800,
                                  color: AppColors.white,
                                ),
                              ),
                              if (user.isVerified) ...[
                                const SizedBox(width: 6),
                                const Icon(Icons.verified, size: 18, color: AppColors.cyan),
                              ],
                            ],
                          ),
                          const SizedBox(height: 4),
                          Text(
                            user.bio.isEmpty ? 'Talent Take30' : user.bio,
                            style: const TextStyle(fontSize: 13, color: AppColors.grey),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // Stats
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    StatBadge(
                      value: '${user.scenesCount}',
                      label: 'Scènes',
                      color: AppColors.white,
                    ),
                    Container(width: 1, height: 36, color: AppColors.border),
                    StatBadge(
                      value: MockData.formatCount(user.followersCount),
                      label: 'Followers',
                      color: AppColors.white,
                    ),
                    Container(width: 1, height: 36, color: AppColors.border),
                    StatBadge(
                      value: MockData.formatCount(user.likesCount),
                      label: 'Likes',
                      color: AppColors.white,
                    ),
                  ],
                ),

                const SizedBox(height: 20),

                // Action buttons
                if (!isOwnProfile)
                  Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () => ref.read(profileProvider('u1').notifier).toggleFollow(),
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 200),
                            height: 42,
                            decoration: BoxDecoration(
                              gradient: user.isFollowing ? null : AppColors.primaryGradient,
                              color: user.isFollowing ? AppColors.surfaceLight : null,
                              borderRadius: BorderRadius.circular(12),
                              border: user.isFollowing
                                  ? Border.all(color: AppColors.border)
                                  : null,
                            ),
                            child: Center(
                              child: Text(
                                user.isFollowing ? 'Suivi ✓' : 'Suivre',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: user.isFollowing ? AppColors.greyLight : AppColors.navy,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Container(
                          height: 42,
                          decoration: BoxDecoration(
                            color: AppColors.surfaceLight,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(color: AppColors.border),
                          ),
                          child: const Center(
                            child: Text(
                              'Message',
                              style: TextStyle(
                                fontSize: 14,
                                fontWeight: FontWeight.w600,
                                color: AppColors.white,
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: const Icon(Icons.share_outlined, color: AppColors.white, size: 18),
                      ),
                    ],
                  )
                else
                  Row(
                    children: [
                      Expanded(
                        child: GestureDetector(
                          onTap: () => context.go('/badges'),
                          child: Container(
                            height: 42,
                            decoration: BoxDecoration(
                              gradient: AppColors.primaryGradient,
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: const Center(
                              child: Text(
                                '🏆 Mes stats',
                                style: TextStyle(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w700,
                                  color: AppColors.navy,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          color: AppColors.surfaceLight,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: AppColors.border),
                        ),
                        child: const Icon(Icons.settings_outlined, color: AppColors.white, size: 18),
                      ),
                    ],
                  ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class _PerformancesTab extends StatelessWidget {
  final List<dynamic> scenes;
  const _PerformancesTab({required this.scenes});

  @override
  Widget build(BuildContext context) {
    if (scenes.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('🎬', style: TextStyle(fontSize: 48)),
            const SizedBox(height: 12),
            const Text(
              'Aucune scène pour l\'instant',
              style: TextStyle(color: AppColors.grey, fontSize: 15),
            ),
            const SizedBox(height: 20),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 60),
              child: PrimaryButton(
                label: 'Enregistrer ma première scène',
                onTap: () => context.go('/record'),
              ),
            ),
          ],
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: scenes.length + 2, // Extra mock items
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 10,
        mainAxisSpacing: 10,
        childAspectRatio: 0.85,
      ),
      itemBuilder: (context, i) {
        final scene = scenes[i % scenes.length];
        return Stack(
          children: [
            SceneCard(
              scene: scene,
              onTap: () => context.go('/scene/${scene.id}'),
            ),
            // Stats overlay bottom
            Positioned(
              bottom: 8,
              right: 8,
              child: Row(
                children: [
                  const Icon(Icons.favorite, size: 10, color: AppColors.red),
                  const SizedBox(width: 3),
                  Text(
                    MockData.formatCount(scene.likesCount),
                    style: const TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w700),
                  ),
                  const SizedBox(width: 6),
                  const Icon(Icons.remove_red_eye_outlined, size: 10, color: AppColors.cyan),
                  const SizedBox(width: 3),
                  Text(
                    MockData.formatCount(scene.viewsCount),
                    style: const TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.w700),
                  ),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

class _BadgesTab extends StatelessWidget {
  final List<BadgeModel> badges;
  const _BadgesTab({required this.badges});

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
      padding: const EdgeInsets.all(20),
      itemCount: badges.length,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        crossAxisSpacing: 14,
        mainAxisSpacing: 14,
        childAspectRatio: 1.1,
      ),
      itemBuilder: (_, i) {
        final badge = badges[i];
        final Color badgeColor;
        switch (badge.type) {
          case BadgeType.gold:
            badgeColor = AppColors.yellow;
            break;
          case BadgeType.silver:
            badgeColor = AppColors.greyLight;
            break;
          case BadgeType.bronze:
            badgeColor = const Color(0xFFCD7F32);
            break;
          case BadgeType.special:
            badgeColor = AppColors.purple;
            break;
        }

        return Container(
          decoration: BoxDecoration(
            color: AppColors.cardDark,
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: badgeColor.withOpacity(0.3)),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 56,
                height: 56,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: badgeColor.withOpacity(0.15),
                  border: Border.all(color: badgeColor.withOpacity(0.4), width: 2),
                ),
                child: Center(
                  child: Text(badge.emoji, style: const TextStyle(fontSize: 28)),
                ),
              ),
              const SizedBox(height: 10),
              Text(
                badge.name,
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w700,
                  color: AppColors.white,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 4),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: Text(
                  badge.description,
                  style: const TextStyle(fontSize: 11, color: AppColors.grey),
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}
