import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';
import '../providers/providers.dart';
import '../widgets/shared_widgets.dart';
import '../services/mock_data.dart';

class BattleScreen extends ConsumerWidget {
  const BattleScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final duelState = ref.watch(duelProvider);

    return Scaffold(
      backgroundColor: AppColors.navy,
      appBar: AppBar(
        backgroundColor: AppColors.navy,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios, color: AppColors.white, size: 20),
          onPressed: () => context.go('/home'),
        ),
        title: const Text('Battle / Duel'),
        centerTitle: true,
      ),
      body: duelState.isLoading
          ? const Center(child: CircularProgressIndicator(color: AppColors.yellow))
          : duelState.duel == null
              ? const Center(child: Text('Aucun duel disponible', style: TextStyle(color: AppColors.grey)))
              : _DuelContent(
                  duel: duelState.duel!,
                  onVote: (choice) => ref.read(duelProvider.notifier).vote(choice),
                ),
    );
  }
}

class _DuelContent extends StatefulWidget {
  final dynamic duel;
  final Function(int) onVote;

  const _DuelContent({required this.duel, required this.onVote});

  @override
  State<_DuelContent> createState() => _DuelContentState();
}

class _DuelContentState extends State<_DuelContent>
    with SingleTickerProviderStateMixin {
  late AnimationController _voteController;

  @override
  void initState() {
    super.initState();
    _voteController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
  }

  @override
  void dispose() {
    _voteController.dispose();
    super.dispose();
  }

  void _handleVote(int choice) {
    _voteController.forward(from: 0);
    widget.onVote(choice);
  }

  @override
  Widget build(BuildContext context) {
    final duel = widget.duel;
    final hasVoted = duel.userVote != null;

    return Column(
      children: [
        // Question
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: Text(
            'Qui a le mieux joué ?',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.w700,
              color: AppColors.white,
            ),
          ),
        ),

        // VS Videos
        Expanded(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Row(
              children: [
                Expanded(
                  child: _SceneVideo(
                    scene: duel.sceneA,
                    label: 'A',
                    votes: duel.votesA,
                    totalVotes: duel.totalVotes,
                    percent: duel.percentA,
                    hasVoted: hasVoted,
                    isWinner: hasVoted && duel.votesA > duel.votesB,
                    onVote: () => _handleVote(0),
                  ),
                ),
                // VS divider
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 8),
                  child: Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: AppColors.surfaceLight,
                      border: Border.all(color: AppColors.border),
                    ),
                    child: const Center(
                      child: Text(
                        'VS',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w800,
                          color: AppColors.yellow,
                        ),
                      ),
                    ),
                  ),
                ),
                Expanded(
                  child: _SceneVideo(
                    scene: duel.sceneB,
                    label: 'B',
                    votes: duel.votesB,
                    totalVotes: duel.totalVotes,
                    percent: duel.percentB,
                    hasVoted: hasVoted,
                    isWinner: hasVoted && duel.votesB > duel.votesA,
                    onVote: () => _handleVote(1),
                  ),
                ),
              ],
            ),
          ),
        ),

        // Vote buttons
        if (!hasVoted)
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(
                  child: _VoteButton(
                    label: '🅰 Voter A',
                    color: AppColors.cyan,
                    onTap: () => _handleVote(0),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _VoteButton(
                    label: '🅱 Voter B',
                    color: AppColors.purple,
                    onTap: () => _handleVote(1),
                  ),
                ),
              ],
            ),
          )
        else
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Text(
                  'Tu as voté pour ${duel.userVote == 0 ? duel.sceneA.author.username : duel.sceneB.author.username} !',
                  style: const TextStyle(
                    color: AppColors.yellow,
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 12),
                // Result bars
                _ResultBar(
                  label: duel.sceneA.author.username,
                  percent: duel.percentA,
                  color: AppColors.cyan,
                ),
                const SizedBox(height: 8),
                _ResultBar(
                  label: duel.sceneB.author.username,
                  percent: duel.percentB,
                  color: AppColors.purple,
                ),
              ],
            ),
          ),

        const SizedBox(height: 16),
      ],
    );
  }
}

class _SceneVideo extends StatelessWidget {
  final dynamic scene;
  final String label;
  final int votes;
  final int totalVotes;
  final double percent;
  final bool hasVoted;
  final bool isWinner;
  final VoidCallback onVote;

  const _SceneVideo({
    required this.scene,
    required this.label,
    required this.votes,
    required this.totalVotes,
    required this.percent,
    required this.hasVoted,
    required this.isWinner,
    required this.onVote,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: hasVoted ? null : onVote,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isWinner ? AppColors.yellow : AppColors.border,
            width: isWinner ? 2 : 1,
          ),
        ),
        clipBehavior: Clip.hardEdge,
        child: Stack(
          children: [
            Positioned.fill(
              child: Image.network(
                scene.thumbnailUrl,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(color: AppColors.cardDark),
              ),
            ),
            const Positioned.fill(
              child: DecoratedBox(
                decoration: BoxDecoration(gradient: AppColors.darkOverlay),
              ),
            ),
            // Label badge
            Positioned(
              top: 10,
              left: 10,
              child: Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: AppColors.yellow,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Center(
                  child: Text(
                    label,
                    style: const TextStyle(
                      fontWeight: FontWeight.w800,
                      color: AppColors.navy,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            ),
            // User info
            Positioned(
              bottom: 10,
              left: 10,
              right: 10,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      UserAvatar(url: scene.author.avatarUrl, size: 24),
                      const SizedBox(width: 6),
                      Text(
                        scene.author.username,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 12,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  if (hasVoted) ...[
                    const SizedBox(height: 4),
                    Text(
                      MockData.formatCount(votes),
                      style: const TextStyle(color: AppColors.yellow, fontSize: 12, fontWeight: FontWeight.w700),
                    ),
                  ],
                ],
              ),
            ),
            if (isWinner)
              Positioned(
                top: 10,
                right: 10,
                child: const Text('🏆', style: TextStyle(fontSize: 20)),
              ),
          ],
        ),
      ),
    );
  }
}

class _VoteButton extends StatelessWidget {
  final String label;
  final Color color;
  final VoidCallback onTap;

  const _VoteButton({required this.label, required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        height: 52,
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.5)),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: color,
              fontSize: 16,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ),
    );
  }
}

class _ResultBar extends StatelessWidget {
  final String label;
  final double percent;
  final Color color;

  const _ResultBar({required this.label, required this.percent, required this.color});

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 80,
          child: Text(
            label,
            style: const TextStyle(color: AppColors.greyLight, fontSize: 12),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(4),
            child: LinearProgressIndicator(
              value: percent,
              backgroundColor: AppColors.surfaceLight,
              valueColor: AlwaysStoppedAnimation(color),
              minHeight: 8,
            ),
          ),
        ),
        const SizedBox(width: 8),
        Text(
          '${(percent * 100).toInt()}%',
          style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700),
        ),
      ],
    );
  }
}
